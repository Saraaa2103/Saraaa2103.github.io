import {rm,mkdir,cp,readFile,writeFile,stat,readdir} from 'node:fs/promises';
import {execFileSync} from 'node:child_process';
import {resolve,relative,sep} from 'node:path';
import {fileURLToPath} from 'node:url';
import {deflateRawSync} from 'node:zlib';

const root=fileURLToPath(new URL('../',import.meta.url)),out=resolve(root,'dist');

// ZIP archives use only Node's standard library, so a clean checkout needs no install.
const crcTable=Array.from({length:256},(_,i)=>{
  for(let bit=0;bit<8;bit++)i=(i>>>1)^((i&1)?0xedb88320:0);
  return i>>>0;
});
function crc32(data){let crc=0xffffffff;for(const byte of data)crc=crcTable[(crc^byte)&255]^(crc>>>8);return (crc^0xffffffff)>>>0;}
async function filesIn(paths,base=root){
  const files=[];
  for(const name of paths){
    const path=resolve(base,name),info=await stat(path);
    if(info.isDirectory())files.push(...await filesIn((await readdir(path)).filter(name=>name!=='.DS_Store').sort().map(name=>relative(base,resolve(path,name))),base));
    else files.push({name:name.split(sep).join('/'),data:await readFile(path)});
  }
  return files;
}
async function writeZip(path,files){
  const localParts=[],directoryParts=[];
  let offset=0,directorySize=0;
  for(const file of files){
    const name=Buffer.from(file.name),compressed=deflateRawSync(file.data),crc=crc32(file.data);
    const local=Buffer.alloc(30);
    local.writeUInt32LE(0x04034b50,0);local.writeUInt16LE(20,4);local.writeUInt16LE(8,8);
    local.writeUInt16LE(33,12); // January 1, 1980: reproducible archive timestamp.
    local.writeUInt32LE(crc,14);local.writeUInt32LE(compressed.length,18);local.writeUInt32LE(file.data.length,22);local.writeUInt16LE(name.length,26);
    const entry=Buffer.alloc(46);
    entry.writeUInt32LE(0x02014b50,0);entry.writeUInt16LE(20,4);entry.writeUInt16LE(20,6);entry.writeUInt16LE(8,10);entry.writeUInt16LE(33,14);
    entry.writeUInt32LE(crc,16);entry.writeUInt32LE(compressed.length,20);entry.writeUInt32LE(file.data.length,24);entry.writeUInt16LE(name.length,28);entry.writeUInt32LE(offset,42);
    localParts.push(local,name,compressed);directoryParts.push(entry,name);
    offset+=local.length+name.length+compressed.length;directorySize+=entry.length+name.length;
  }
  const end=Buffer.alloc(22);
  end.writeUInt32LE(0x06054b50,0);end.writeUInt16LE(files.length,8);end.writeUInt16LE(files.length,10);end.writeUInt32LE(directorySize,12);end.writeUInt32LE(offset,16);
  await writeFile(path,Buffer.concat([...localParts,...directoryParts,end]));
}

for(const path of ['src/app.js','src/core.js','src/catalog.js','extension/service-worker.mjs','extension/content-bridge.js'])execFileSync(process.execPath,['--check',path],{cwd:root,stdio:'inherit'});
await rm(out,{recursive:true,force:true});await mkdir(out,{recursive:true});
for(const path of ['index.html','src','LICENSE','NOTICE'])await cp(resolve(root,path),resolve(out,path),{recursive:true});
await cp(resolve(root,'public'),out,{recursive:true});
await writeFile(resolve(out,'.nojekyll'),'');
await writeZip(resolve(out,'streambert-protection.zip'),await filesIn((await readdir(resolve(root,'extension'))).filter(name=>name!=='.DS_Store').sort(),resolve(root,'extension')));
const sourcePaths=['index.html','package.json','server.mjs','src','public','scripts','extension','shared','tests','README.md','LICENSE','NOTICE','.gitignore'];
for(const path of ['.github','package-lock.json'])if(await stat(resolve(root,path)).catch(()=>null))sourcePaths.push(path);
// Hosting identity stays in the local Sites project and is not distributed.
await writeZip(resolve(out,'streambert-web-source.zip'),await filesIn(sourcePaths));
console.log(JSON.stringify({output:out,extensionBytes:(await stat(resolve(out,'streambert-protection.zip'))).size,sourceBytes:(await stat(resolve(out,'streambert-web-source.zip'))).size}));
