# Streambert Web

A lightweight browser adaptation of [Streambert](https://github.com/truelockmc/streambert), based on upstream v2.6.0, commit `18207c43fc982d4a25ad8f061690cb6fda8b452e`. GPL-3.0-only. Native JavaScript modules and CSS, with no framework or production package dependencies.

## Use it

Open [Streambert on GitHub Pages](https://saraaa2103.github.io/streambert/) or the existing [Sites deployment](https://streambert-light-web.foggylyric32.chatgpt.site/).

For local development, run `npm run dev`, then open http://localhost:5173. Node 22+ is recommended. For a production static build run `npm run build`; serve `dist/` over HTTPS. No dependency install, ZIP utility, or Sites project identity is needed. The same build works at a domain root or under a path such as `/streambert/` because app assets, downloads, fonts, and the install manifest use relative URLs. `dist/` includes `.nojekyll`, the companion ZIP, and a complete editable source ZIP. Existing Sites projects can continue deploying `dist/` with their local `.openai/hosting.json`; this identity is excluded from the distributed source.

- Browse a small, fixed starter collection. Its scores are illustrative, not current TMDB ratings.
- Add your own TMDB API Read Access Token in Settings for live catalogue discovery, movie/series/anime search, genres, and full metadata. Credentials go directly to TMDB; no shared key is embedded in the app.
- Tokens are session-only by default. The explicit remember option uses unencrypted localStorage. No server-side account, analytics, or library database is used.
- Save titles locally, see recently opened titles, and merge/export JSON backups. Backups never contain API tokens.
- Play local browser-supported video files without uploading them, with optional WebVTT subtitles.
- Choose Videasy, VidSrc, or Vidking in a separate protected player tab after companion 1.1.0 is connected. TV season/episode controls are supported; episode selection is manual. Provider availability, legal access and browser embedding restrictions still apply.

## Real ad and tracker blocking

VidSrc and Videasy explicitly reject sandboxed frames. The web page no longer embeds external players; its CSP now has `frame-src 'none'`. Companion **1.1.0** opens an isolated extension-owned player tab instead. Install the updated companion from Privacy & protection, replacing the older extension, then reload Streambert. No provider loads with the previous companion; the app shows an update prompt.

The companion creates its own page first, installs and reads back the original known-host DNR blocking rules plus an HTTP(S) main-frame navigation guard, then supplies a validated provider URL to that page. The provider iframe has no sandbox attribute, so the anti-sandbox check no longer blocks this player. Page redirects out of the extension-owned tab are blocked. Player-created popup tabs are closed using their source tab ID. Closing popups happens after creation and cannot guarantee their first network request is prevented. Browser defaults still apply to third-party permissions and downloads.

Sessions are kept in browser-session storage so service-worker suspension does not lose the owner/player relationship. Closing or leaving the owner Streambert page closes its player. No arbitrary URL from the page is accepted; only known sources and numeric TMDB/episode identifiers. Browser navigation events and session-storage permissions are used to manage these related tabs. The companion does not read your TMDB token or watchlist. See [extension/README.md](extension/README.md) for implementation, permission details, and limits.

Known-host blocking reduces ads and trackers; it is not a comprehensive filter engine and cannot guarantee zero ads/tracking. Providers receive your IP address and player requests. Provider CSP and X-Frame-Options are respected; no response headers are stripped or proxied. Playback availability and browser restrictions still apply. A successful player launch means its protection was installed, not that a third-party stream was verified playable.

The companion supports `https://saraaa2103.github.io/streambert/`, the existing Sites deployment, and local port 5173. Other account Pages projects cannot activate it. For another deployment, update manifest matches/host permissions and the allowed-app policy. Firefox and Safari need a separate extension adaptation; playback stays gated there.

## Deliberate browser limits

Electron stream extraction, multithreaded/ffmpeg downloads, AllManga's Node resolver/proxy, cross-origin video inspection, Discord IPC, OS keychain storage and desktop auto-updates do not carry over. The web app provides native local video playback; it does not offer a misleading download button for third-party streams. Recently opened records are app-owned history, not claimed playback progress. External players own their progress and subtitle controls.

## Development and verification

`npm test` checks ad/tracker rule scope and lifecycle, the content bridge, player URL boundaries, protection gates, backup validation, and assets at both root and GitHub Pages paths. `npm run build` checks module syntax, copies static assets and generates companion/source ZIPs. No dependency install is needed. The `extension/` directory is itself ready for Load unpacked. When moving between hosts, export your library from Settings and import it on the new host; browser storage is separate for each origin. Known starter artwork in older backups is normalized to the new app location.

The default catalogue is static starter content, not a live trending feed. Live metadata comes from TMDB. Assets and upstream attribution are in NOTICE and public/posters/SOURCES.md. The complete editable source is distributed in `./streambert-web-source.zip`, alongside `./LICENSE` in the deployed app.
