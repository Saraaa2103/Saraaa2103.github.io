# Streambert Web

A lightweight browser adaptation of [Streambert](https://github.com/truelockmc/streambert), based on upstream v2.6.0, commit `18207c43fc982d4a25ad8f061690cb6fda8b452e`. GPL-3.0-only. Native JavaScript modules and CSS, with no framework or production package dependencies.

## Use it

Open [Streambert on GitHub Pages](https://saraaa2103.github.io/streambert/) or the existing [Sites deployment](https://streambert-light-web.foggylyric32.chatgpt.site/).

For local development, run `npm run dev`, then open http://localhost:5173. Node 22+ is recommended. For a production static build run `npm run build`; serve `dist/` over HTTPS. No dependency install, ZIP utility, or Sites project identity is needed. The same build works at a domain root or under a path such as `/streambert/` because app assets, downloads, fonts, and the install manifest use relative URLs. `dist/` includes `.nojekyll`, the companion ZIP, and a complete editable source ZIP. Existing Sites projects can continue deploying `dist/` with their local `.openai/hosting.json`; this identity is excluded from the distributed source.

- Browse a small, fixed starter collection. Its scores are illustrative, not current TMDB ratings.
- Add your own TMDB API Read Access Token in Settings for live catalogue discovery, movie/series/anime search, genres, and full metadata. Credentials go directly to TMDB; no shared key is embedded in the app.
- Tokens are session-only by default. The explicit remember option uses unencrypted localStorage. No server-side account, analytics, or library database is used.
- Save titles locally, see recently opened titles, and merge/export JSON backups. Backups never contain API tokens.
- Play local browser-supported video files without uploading them, with optional WebVTT subtitles.
- Choose Videasy, VidSrc, or Vidking for embedded playback after the companion is connected. TV season/episode controls are supported; episode selection is manual. Provider availability, legal access and browser embedding restrictions still apply.

## Real ad and tracker blocking

A normal page cannot cancel requests in cross-origin player frames. This port therefore requires the included Chromium MV3 extension before it creates a third-party player iframe. Download the companion from Privacy & protection, unzip, enable Developer mode at `chrome://extensions` or `edge://extensions`, choose Load unpacked, then reload the app. See [extension/README.md](extension/README.md) for the permission model.

The content bridge acknowledges protection only after Chrome accepts and returns the expected per-tab declarativeNetRequest rules. The app periodically rechecks the companion and closes an open embedded player if the bridge is lost. This handshake is an operational status check, not remote attestation. The list blocks known hosts from upstream; it is not a comprehensive filter engine and cannot guarantee zero ads/tracking. Third-party providers receive your IP address and player requests.

Iframe sandboxing independently disallows popups, top navigation, forms and downloads. It does not itself block network tracking. Provider CSP and X-Frame-Options are respected, so some sources may not embed. This port never proxies or strips embedding headers. No external player loads merely from opening a movie's detail view. Library backups accept artwork only from local starter assets or the TMDB image CDN.

The companion supports the GitHub Pages app at `https://saraaa2103.github.io/streambert/`, the existing Sites deployment, and local port 5173. For another deployment, update both its manifest matches/host permissions and the policy's allowed app location before loading it. Firefox and Safari require a separate extension adaptation; embedded playback stays gated there.

## Deliberate browser limits

Electron stream extraction, multithreaded/ffmpeg downloads, AllManga's Node resolver/proxy, cross-origin video inspection, Discord IPC, OS keychain storage and desktop auto-updates do not carry over. The web app provides native local video playback; it does not offer a misleading download button for third-party streams. Recently opened records are app-owned history, not claimed playback progress. External players own their progress and subtitle controls.

## Development and verification

`npm test` checks ad/tracker rule scope and lifecycle, the content bridge, player URL boundaries, protection gates, backup validation, and assets at both root and GitHub Pages paths. `npm run build` checks module syntax, copies static assets and generates companion/source ZIPs. No dependency install is needed. The `extension/` directory is itself ready for Load unpacked. When moving between hosts, export your library from Settings and import it on the new host; browser storage is separate for each origin. Known starter artwork in older backups is normalized to the new app location.

The default catalogue is static starter content, not a live trending feed. Live metadata comes from TMDB. Assets and upstream attribution are in NOTICE and public/posters/SOURCES.md. The complete editable source is distributed in `./streambert-web-source.zip`, alongside `./LICENSE` in the deployed app.
