import assert from 'node:assert/strict';
import fs from 'node:fs/promises';
import vm from 'node:vm';
import test from 'node:test';
import {
  APP_ORIGINS, BLOCKED_DOMAINS, BLOCKED_DOMAIN_COUNT, BLOCKED_RESOURCE_TYPES,
  ORIGINAL_BLOCK_PATTERNS, allocateRuleIds, createProtectionRules,
  hasCompleteProtection, hostMatchesDomain, isAllowedAppUrl, shouldBlockRequest,
} from '../shared/protection-policy.mjs';
import { createSessionProtection } from '../extension/session-protection.mjs';

function request(url, resourceType = 'script', tabId = 42) {
  return { url, resourceType, tabId };
}

test('all upstream patterns are represented, deduplicated, and protected', () => {
  assert.equal(ORIGINAL_BLOCK_PATTERNS.length, 51);
  assert.equal(BLOCKED_DOMAIN_COUNT, 49);
  assert.equal(new Set(BLOCKED_DOMAINS).size, BLOCKED_DOMAIN_COUNT);
  for (const pattern of ORIGINAL_BLOCK_PATTERNS) {
    const url = pattern.replace('*://', 'https://').replace('*.doubleclick', 'nested.doubleclick').replace(/\*$/, 'request');
    assert.equal(shouldBlockRequest(request(url), 42), true, pattern);
  }
});

test('domain boundaries do not match query strings, impostors or sibling domains', () => {
  assert.equal(hostMatchesDomain('deep.doubleclick.net', 'doubleclick.net'), true);
  for (const url of [
    'https://notdoubleclick.net/ad.js',
    'https://doubleclick.net.example.org/ad.js',
    'https://example.org/?next=https://doubleclick.net/ad.js',
    'https://example.org/doubleclick.net/ad.js',
    'https://api.themoviedb.org/3/search/movie',
    'https://image.tmdb.org/t/p/w500/poster.jpg',
    'https://vidlink.pro/movie/123',
  ]) assert.equal(shouldBlockRequest(request(url), 42), false, url);
});

test('upstream path-specific block does not block unrelated yt3 images', () => {
  assert.equal(shouldBlockRequest(request('https://yt3.ggpht.com/ytc/avatar'), 42), true);
  assert.equal(shouldBlockRequest(request('https://sub.yt3.ggpht.com:8443/ytc/avatar'), 42), true);
  for (const path of ['/avatar', '/ytc', '/YTc/avatar', '/prefix/ytc/avatar', '/?next=/ytc/avatar']) {
    assert.equal(shouldBlockRequest(request(`https://yt3.ggpht.com${path}`), 42), false, path);
  }
});

test('blocking covers nested frames, images, scripts, media, trackers and websockets in one tab', () => {
  for (const resourceType of BLOCKED_RESOURCE_TYPES) {
    assert.equal(shouldBlockRequest(request('https://sub.doubleclick.net/ad', resourceType), 42), true, resourceType);
    assert.equal(shouldBlockRequest(request('https://sub.doubleclick.net/ad', resourceType, 43), 42), false, resourceType);
  }
  assert.equal(shouldBlockRequest(request('wss://doubleclick.net/ad', 'websocket'), 42), true);
  assert.equal(shouldBlockRequest(request('https://doubleclick.net/', 'main_frame'), 42), false);
  assert.equal(shouldBlockRequest(request('not a url'), 42), false);
});

test('app origins require exact scheme, hostname and development port', () => {
  for (const origin of APP_ORIGINS.filter((origin) => origin !== 'https://saraaa2103.github.io')) {
    assert.equal(isAllowedAppUrl(`${origin}/watch?id=1`), true);
  }
  for (const value of [
    'https://streambert-light-web.foggylyric32.chatgpt.site.evil.test/',
    'http://streambert-light-web.foggylyric32.chatgpt.site/',
    'http://localhost:5174/', 'https://localhost:5173/', 'http://localhost:5173.evil.test/',
    'http://user:pass@localhost:5173/', 'not a url', undefined,
  ]) assert.equal(isAllowedAppUrl(value), false, String(value));
});

test('GitHub Pages protection requires the canonical Streambert directory', () => {
  for (const path of ['/streambert', '/streambert/', '/streambert/watch?id=1#player']) {
    assert.equal(isAllowedAppUrl(`https://saraaa2103.github.io${path}`), true, path);
  }
  for (const value of [
    'https://saraaa2103.github.io/',
    'https://saraaa2103.github.io/other-project/',
    'https://saraaa2103.github.io/streambert-other/',
    'https://saraaa2103.github.io/Streambert/',
    'https://saraaa2103.github.io/?next=/streambert/',
    'https://saraaa2103.github.io/#/streambert/',
    'https://saraaa2103.github.io/%73treambert/',
    'https://saraaa2103.github.io/streambert%2fwatch',
    'https://saraaa2103.github.io/streambert/%2fother',
    'https://saraaa2103.github.io/streambert/%5cother',
    'https://saraaa2103.github.io/streambert/../other-project/',
    'https://saraaa2103.github.io/other/../streambert/',
    'https://saraaa2103.github.io/streambert/%2e%2e/streambert/',
    'https://saraaa2103.github.io/streambert\\other',
    'https://saraaa2103.github.io.evil.test/streambert/',
    'https://saraaa2103.github.io:8443/streambert/',
    'https://saraaa2103.github.io@evil.test/streambert/',
    'https://user:pass@saraaa2103.github.io/streambert/',
    'http://saraaa2103.github.io/streambert/',
  ]) assert.equal(isAllowedAppUrl(value), false, value);
});

test('DNR rules have explicit tab scope, block actions, resource types and safe IDs', () => {
  const rules = createProtectionRules(42, [5, 8]);
  assert.equal(hasCompleteProtection(rules, 42), true);
  assert.equal(hasCompleteProtection(rules, 43), false);
  assert.equal(hasCompleteProtection([rules[0]], 42), false);
  for (const rule of rules) {
    assert.deepEqual(rule.condition.tabIds, [42]);
    assert.equal(rule.action.type, 'block');
    assert.equal(rule.condition.resourceTypes.includes('main_frame'), false);
    assert.equal('initiatorDomains' in rule.condition, false, 'nested provider origins remain covered');
  }
  const regex = new RegExp(rules[1].condition.regexFilter);
  assert.equal(regex.test('https://yt3.ggpht.com/ytc/avatar'), true);
  assert.equal(regex.test('https://yt3.ggpht.com:8443/ytc/avatar'), true);
  assert.equal(regex.test('https://yt3.ggpht.com/other/ytc/avatar'), false);
  assert.throws(() => createProtectionRules(-1, [1, 2]));
  assert.throws(() => createProtectionRules(1, [1, 1]));
  assert.throws(() => createProtectionRules(1, [0, 2]));
  assert.deepEqual(allocateRuleIds([{ id: 1 }, { id: 3 }]), [2, 4]);
  const altered = structuredClone(rules);
  altered[0].condition.initiatorDomains = ['only.some-provider.test'];
  assert.equal(hasCompleteProtection(altered, 42), false, 'narrower rules cannot claim full protection');
});

function fakeChrome({ rules = [], tabs = new Map([[42, { id: 42, url: `${APP_ORIGINS[0]}/` }]]) } = {}) {
  let storedRules = structuredClone(rules);
  const updates = [];
  const chromeApi = {
    tabs: {
      async get(id) { if (!tabs.has(id)) throw new Error('Tab closed.'); return tabs.get(id); },
      async query() { return [...tabs.values()]; },
    },
    declarativeNetRequest: {
      async getSessionRules() { return structuredClone(storedRules); },
      async updateSessionRules({ removeRuleIds = [], addRules = [] }) {
        const next = storedRules.filter((rule) => !removeRuleIds.includes(rule.id));
        const ids = new Set(next.map((rule) => rule.id));
        for (const rule of addRules) {
          if (ids.has(rule.id)) throw new Error('Duplicate rule ID.');
          ids.add(rule.id);
          next.push(structuredClone(rule));
        }
        storedRules = next;
        updates.push({ removeRuleIds, addRules });
      },
    },
  };
  return { chromeApi, tabs, updates, get rules() { return storedRules; } };
}

test('active is returned only after installed rules are read back and verified', async () => {
  const fake = fakeChrome();
  const manager = createSessionProtection(fake.chromeApi);
  assert.equal(await manager.ensure(42), true);
  assert.equal(fake.updates.length, 1);
  assert.equal(hasCompleteProtection(fake.rules, 42), true);
  const failure = fakeChrome();
  failure.chromeApi.declarativeNetRequest.updateSessionRules = async () => {};
  await assert.rejects(createSessionProtection(failure.chromeApi).ensure(42), /verification failed/);
});

test('concurrent tabs and repeated checks never produce duplicate IDs', async () => {
  const fake = fakeChrome();
  fake.tabs.set(43, { id: 43, url: `${APP_ORIGINS[0]}/watch` });
  const manager = createSessionProtection(fake.chromeApi);
  assert.deepEqual(await Promise.all([manager.ensure(42), manager.ensure(43), manager.ensure(42)]), [true, true, true]);
  assert.equal(fake.rules.length, 4);
  assert.equal(new Set(fake.rules.map((rule) => rule.id)).size, 4);
  assert.equal(fake.updates.length, 2);
  assert.equal(hasCompleteProtection(fake.rules, 42), true);
  assert.equal(hasCompleteProtection(fake.rules, 43), true);
});

test('worker restart reuses browser session rules and closing one tab preserves the other', async () => {
  const fake = fakeChrome({ rules: [...createProtectionRules(42, [11, 12]), ...createProtectionRules(43, [13, 14])] });
  fake.tabs.set(43, { id: 43, url: `${APP_ORIGINS[0]}/watch` });
  const restarted = createSessionProtection(fake.chromeApi);
  assert.equal(await restarted.ensure(42), true);
  assert.equal(fake.updates.length, 0);
  await restarted.remove(42);
  assert.equal(hasCompleteProtection(fake.rules, 42), false);
  assert.equal(hasCompleteProtection(fake.rules, 43), true);
});

test('navigating away removes scoped rules; partial rules are replaced atomically', async () => {
  const fake = fakeChrome({ rules: createProtectionRules(42, [7, 8]).slice(0, 1) });
  const manager = createSessionProtection(fake.chromeApi);
  await manager.ensure(42);
  assert.equal(fake.rules.length, 2);
  assert.deepEqual(fake.updates[0].removeRuleIds, [7]);
  fake.tabs.set(42, { id: 42 }); // unrelated tabs do not expose URL with our permissions
  await assert.rejects(manager.ensure(42), /only available/);
  assert.equal(fake.rules.length, 0);
});

test('pruning removes closed/unrelated tabs while retaining active tab rules', async () => {
  const fake = fakeChrome({ rules: [...createProtectionRules(42, [1, 2]), ...createProtectionRules(43, [3, 4])] });
  await createSessionProtection(fake.chromeApi).prune();
  assert.equal(hasCompleteProtection(fake.rules, 42), true);
  assert.equal(fake.rules.length, 2);
});

test('GitHub Pages app keeps rules until navigation leaves its project directory', async () => {
  const fake = fakeChrome({ tabs: new Map([[42, { id: 42, url: 'https://saraaa2103.github.io/streambert/' }]]) });
  const manager = createSessionProtection(fake.chromeApi);
  assert.equal(await manager.ensure(42), true);
  assert.equal(hasCompleteProtection(fake.rules, 42), true);
  fake.tabs.set(42, { id: 42, url: 'https://saraaa2103.github.io/another-project/' });
  await assert.rejects(manager.ensure(42), /only available/);
  assert.equal(fake.rules.length, 0);
});

test('manifest limits content access to app URLs, including only the GitHub project directory', async () => {
  const manifest = JSON.parse(await fs.readFile(new URL('../extension/manifest.json', import.meta.url)));
  assert.equal(manifest.version, '1.1.0');
  assert.deepEqual(manifest.permissions, ['declarativeNetRequest', 'storage', 'webNavigation']);
  assert.deepEqual(manifest.host_permissions, [
    'https://streambert-light-web.foggylyric32.chatgpt.site/*',
    'https://saraaa2103.github.io/streambert/*',
    'http://localhost:5173/*',
    'http://127.0.0.1:5173/*',
  ]);
  assert.equal(manifest.content_scripts[0].all_frames, false);
  assert.deepEqual(manifest.content_scripts[0].matches, manifest.host_permissions);
});

test('isolated content bridge checks origin/source/nonce and preserves the request nonce', async () => {
  const code = await fs.readFile(new URL('../extension/content-bridge.js', import.meta.url), 'utf8');
  let listener;
  const output = [];
  const page = {
    location: { origin: APP_ORIGINS[0] },
    addEventListener(type, fn) { assert.equal(type, 'message'); listener = fn; },
    postMessage(data, origin) { output.push({ data, origin }); },
  };
  const runtime = { sendMessage: async () => ({ active: true, version: '1.0.1', blockedDomains: BLOCKED_DOMAIN_COUNT }) };
  vm.runInNewContext(code, { window: page, chrome: { runtime } });
  const data = { channel: 'streambert-web', type: 'PROTECTION_CHECK', nonce: 'test-nonce-123' };
  await listener({ data, source: {}, origin: APP_ORIGINS[0] });
  await listener({ data, source: page, origin: 'https://bad.example' });
  assert.equal(output.length, 0);
  await listener({ data, source: page, origin: APP_ORIGINS[0] });
  assert.equal(output.length, 1);
  assert.equal(output[0].data.active, true);
  assert.equal(output[0].data.nonce, data.nonce);
  assert.equal(output[0].data.channel, 'streambert-protection');
  assert.equal(output[0].origin, APP_ORIGINS[0]);
  runtime.sendMessage = async () => { throw new Error('Disabled'); };
  await listener({ data, source: page, origin: APP_ORIGINS[0] });
  assert.equal(output[1].data.active, false);
});
