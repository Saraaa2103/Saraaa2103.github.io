import assert from 'node:assert/strict';
import fs from 'node:fs/promises';
import vm from 'node:vm';
import test from 'node:test';
import { createDnrQueue, createSessionProtection } from '../extension/session-protection.mjs';
import { createPlayerManager, PLAYER_STORAGE_KEY } from '../extension/player-manager.mjs';
import { installServiceWorker } from '../extension/service-worker.mjs';
import { isAppSender, isPlayerSender, selectedProviderUrl, validatePlayerSelection } from '../extension/player-policy.mjs';
import { createPlayerProtectionRules, createProtectionRules, hasCompletePlayerProtection, hasCompleteProtection, shouldBlockRequest } from '../shared/protection-policy.mjs';

const appUrl = 'https://saraaa2103.github.io/streambert/';
const selection = { source: 'vidsrc', type: 'movie', id: 123, season: 1, episode: 1, title: 'Test movie' };
const copy = (value) => structuredClone(value);
function event() {
  const listeners = [];
  return { listeners, addListener(fn) { listeners.push(fn); }, emit(...args) { return listeners.map((fn) => fn(...args)); } };
}
function fakeChrome({ saved = [], initialRules = [] } = {}) {
  let rules = copy(initialRules);
  let nextTabId = 100;
  const tabs = new Map([[42, { id: 42, url: appUrl }], [43, { id: 43, url: appUrl }]]);
  const data = { [PLAYER_STORAGE_KEY]: copy(saved) };
  const log = [];
  const api = {
    runtime: { id: 'extension-id', getURL(path) { return `chrome-extension://extension-id/${path}`; },
      getManifest() { return { version: '1.1.0' }; }, onMessage: event(), onInstalled: event(), onStartup: event() },
    storage: { session: { async get(key) { return copy({ [key]: data[key] }); }, async set(value) { Object.assign(data, copy(value)); } } },
    tabs: {
      onRemoved: event(), onUpdated: event(), onCreated: event(),
      async get(id) { if (!tabs.has(id)) throw new Error('Tab closed.'); return copy(tabs.get(id)); },
      async query() { return [...tabs.values()].map(copy); },
      async create(options) { const tab = { id: nextTabId++, ...options }; tabs.set(tab.id, tab); log.push(['create', tab.id]); return copy(tab); },
      async remove(id) { log.push(['close', id]); tabs.delete(id); },
      async update(id, changes) { if (!tabs.has(id)) throw new Error('Tab closed.'); Object.assign(tabs.get(id), changes); log.push(['update', id]); return copy(tabs.get(id)); },
    },
    declarativeNetRequest: {
      async getSessionRules() { log.push(['read-rules']); return copy(rules); },
      async updateSessionRules({ addRules = [], removeRuleIds = [] }) {
        const next = rules.filter((rule) => !removeRuleIds.includes(rule.id));
        const ids = new Set(next.map((rule) => rule.id));
        for (const rule of addRules) { assert.equal(ids.has(rule.id), false, 'duplicate rule ID'); ids.add(rule.id); next.push(copy(rule)); }
        rules = next; log.push(['rules', ...removeRuleIds]);
      },
    },
    webNavigation: { onCreatedNavigationTarget: event() },
  };
  const sender = (id = 42) => ({ id: api.runtime.id, frameId: 0, tab: copy(tabs.get(id)), url: tabs.get(id)?.url });
  return { api, tabs, data, log, sender, get rules() { return rules; } };
}
function manager(fake, options) {
  const protection = createSessionProtection(fake.api, createDnrQueue());
  return { players: createPlayerManager(fake.api, protection, options), protection };
}
async function waitFor(condition) {
  for (let attempt = 0; attempt < 100; attempt++) {
    if (condition()) return;
    await new Promise((resolve) => setImmediate(resolve));
  }
  assert.fail('Expected asynchronous condition was not reached.');
}
async function launch(fake, players, payload = selection, owner = 42) {
  const previousId = fake.data[PLAYER_STORAGE_KEY].find((record) => record.ownerTabId === owner)?.playerTabId;
  const result = players.open(fake.sender(owner), payload);
  await waitFor(() => fake.data[PLAYER_STORAGE_KEY].some((record) => record.ownerTabId === owner && record.playerTabId !== previousId));
  const id = fake.data[PLAYER_STORAGE_KEY].find((record) => record.ownerTabId === owner).playerTabId;
  const configuration = await players.configure(fake.sender(id));
  await players.acknowledge(fake.sender(id));
  assert.deepEqual(await result, { ok: true });
  return { id, configuration };
}

test('selection accepts known source/type/positive ids only, never URLs or unexpected fields', () => {
  assert.deepEqual(validatePlayerSelection(selection), selection);
  assert.equal(selectedProviderUrl(selection), 'https://vsembed.su/embed/movie/123');
  assert.equal(selectedProviderUrl({ ...selection, source: 'vidking' }), 'https://www.vidking.net/embed/movie/123');
  assert.equal(selectedProviderUrl({ ...selection, source: 'videasy', type: 'tv', season: 2, episode: 4 }), 'https://player.videasy.to/tv/123/2/4');
  for (const changed of [null, { ...selection, source: '__proto__' }, { ...selection, type: 'anime' },
    { ...selection, id: '123' }, { ...selection, id: 0 }, { ...selection, id: Number.MAX_SAFE_INTEGER + 1 },
    { ...selection, season: 0 }, { ...selection, episode: 10001 }, { ...selection, title: 'a'.repeat(241) },
    { ...selection, title: 'evil\nmovie' }, { ...selection, url: 'https://evil.example/' }]) {
    assert.throws(() => validatePlayerSelection(changed));
  }
});

test('sender checks reject other extensions, nested frames and noncanonical owner/player URLs', () => {
  const fake = fakeChrome();
  assert.equal(isAppSender(fake.api, fake.sender()), true);
  assert.equal(isAppSender(fake.api, { ...fake.sender(), id: 'other-id' }), false);
  assert.equal(isAppSender(fake.api, { ...fake.sender(), frameId: 1 }), false);
  assert.equal(isAppSender(fake.api, { ...fake.sender(), url: 'https://saraaa2103.github.io/other/' }), false);
  const wrapper = { ...fake.sender(), url: fake.api.runtime.getURL('player.html') };
  assert.equal(isPlayerSender(fake.api, wrapper), true);
  assert.equal(isPlayerSender(fake.api, { ...wrapper, url: `${wrapper.url}?url=https://evil.example` }), false);
  assert.equal(isPlayerSender(fake.api, { ...wrapper, frameId: 2 }), false);
});

test('managed player guard covers all HTTP(S) top-level navigation while allowing nested provider resources', () => {
  const rules = createPlayerProtectionRules(100, [5, 6, 7]);
  assert.equal(hasCompletePlayerProtection(rules, 100), true);
  assert.equal(hasCompletePlayerProtection(rules.slice(0, 2), 100), false);
  assert.equal(hasCompleteProtection(rules, 100), false);
  const guard = rules[2];
  assert.deepEqual(guard.condition.resourceTypes, ['main_frame']);
  assert.deepEqual(guard.condition.tabIds, [100]);
  assert.equal(guard.action.type, 'block');
  for (const url of ['http://evil.example/', 'https://player.videasy.to/movie/123', 'https://app.example/']) assert.match(url, new RegExp(guard.condition.regexFilter));
  assert.doesNotMatch('chrome-extension://extension-id/player.html', new RegExp(guard.condition.regexFilter));
  assert.equal(shouldBlockRequest({ url: 'https://vsembed.su/embed/movie/123', resourceType: 'sub_frame', tabId: 100 }, 100), false);
  assert.equal(shouldBlockRequest({ url: 'https://doubleclick.net/ad', resourceType: 'sub_frame', tabId: 100 }, 100), true);
  const altered = copy(rules); altered[2].condition.requestDomains = ['only.evil.example'];
  assert.equal(hasCompletePlayerProtection(altered, 100), false);
});

test('OPEN_PLAYER stays pending until wrapper received configuration and acknowledged startup', async () => {
  const fake = fakeChrome(); const { players } = manager(fake); await players.ready();
  let completed = false;
  const result = players.open(fake.sender(), selection).then((value) => { completed = true; return value; });
  await waitFor(() => fake.data[PLAYER_STORAGE_KEY].length === 1);
  const id = fake.data[PLAYER_STORAGE_KEY][0].playerTabId;
  assert.equal(hasCompletePlayerProtection(fake.rules, id), true);
  assert.equal(completed, false);
  const config = await players.configure(fake.sender(id));
  assert.equal(config.url, 'https://vsembed.su/embed/movie/123');
  assert.equal(completed, false);
  await players.acknowledge(fake.sender(id));
  assert.deepEqual(await result, { ok: true });
  await players.close(fake.sender());
});

test('invalid sender/payload cannot create a player or receive provider configuration', async () => {
  const fake = fakeChrome(); const { players } = manager(fake); await players.ready();
  await assert.rejects(players.open({ ...fake.sender(), frameId: 1 }, selection), /sender/);
  await assert.rejects(players.open(fake.sender(), { ...selection, url: 'https://evil.example' }), /selection/);
  await assert.rejects(players.configure({ ...fake.sender(), url: fake.api.runtime.getURL('player.html') }), /session/);
  await assert.rejects(players.open({ ...fake.sender(), url: 'http://localhost:5173/' }, selection), /no longer/);
  assert.equal(fake.log.some(([name]) => name === 'create'), false);
});

test('failed rule verification closes incomplete player and never sends provider URL', async () => {
  const fake = fakeChrome(); const { players } = manager(fake); await players.ready();
  fake.api.declarativeNetRequest.updateSessionRules = async () => {};
  await assert.rejects(players.open(fake.sender(), selection), /verification failed/);
  assert.equal(fake.data[PLAYER_STORAGE_KEY].length, 0);
  assert.equal([...fake.tabs.values()].some((tab) => tab.url.startsWith('chrome-extension:')), false);
  assert.equal(fake.rules.length, 0);
});

test('app and player mutations share allocation queue, including simultaneous launches', async () => {
  const fake = fakeChrome(); const { players, protection } = manager(fake); await players.ready();
  await Promise.all([protection.ensure(42), protection.ensure(43), launch(fake, players, selection, 42), launch(fake, players, selection, 43)]);
  assert.equal(fake.rules.length, 10);
  assert.equal(new Set(fake.rules.map((rule) => rule.id)).size, 10);
  assert.equal(hasCompleteProtection(fake.rules, 42), true);
  assert.equal(hasCompleteProtection(fake.rules, 43), true);
  await players.close(fake.sender(42)); await players.close(fake.sender(43));
});

test('one player per app owner and close/focus affect only that owner', async () => {
  const fake = fakeChrome(); const { players } = manager(fake); await players.ready();
  const a = await launch(fake, players, selection, 42);
  const b = await launch(fake, players, selection, 43);
  const c = await launch(fake, players, { ...selection, source: 'videasy' }, 42);
  assert.equal(fake.tabs.has(a.id), false);
  assert.equal(fake.tabs.has(b.id), true);
  assert.equal(fake.tabs.has(c.id), true);
  assert.equal(fake.data[PLAYER_STORAGE_KEY].length, 2);
  await players.focus(fake.sender(42)); assert.equal(fake.log.at(-1)[1], c.id);
  await players.close(fake.sender(42)); assert.equal(fake.tabs.has(b.id), true);
  await players.close(fake.sender(43));
});

test('owner navigation closes player before deleting its rules and leaves other app tabs protected', async () => {
  const fake = fakeChrome(); const { players, protection } = manager(fake); await players.ready();
  await protection.ensure(42); await protection.ensure(43);
  const { id } = await launch(fake, players);
  fake.log.length = 0;
  fake.tabs.set(42, { id: 42 });
  await players.onUpdated(42, { status: 'loading' }, fake.tabs.get(42));
  assert.equal(fake.tabs.has(id), false);
  assert.equal(hasCompletePlayerProtection(fake.rules, id), false);
  assert.equal(hasCompleteProtection(fake.rules, 42), false);
  assert.equal(hasCompleteProtection(fake.rules, 43), true);
  assert.ok(fake.log.findIndex(([name]) => name === 'close') < fake.log.findIndex(([name]) => name === 'rules'));
});

test('owner close removes player session/rules, and failed close retains protection/session', async () => {
  const fake = fakeChrome(); const { players } = manager(fake); await players.ready();
  const { id } = await launch(fake, players);
  fake.api.tabs.remove = async () => { throw new Error('Cannot close.'); };
  await assert.rejects(players.close(fake.sender()), /Cannot close/);
  assert.equal(hasCompletePlayerProtection(fake.rules, id), true);
  assert.equal(fake.data[PLAYER_STORAGE_KEY].length, 1);
  fake.api.tabs.remove = async (tabId) => fake.tabs.delete(tabId);
  fake.tabs.delete(42);
  await players.onRemoved(42);
  assert.equal(fake.tabs.has(id), false);
  assert.equal(fake.data[PLAYER_STORAGE_KEY].length, 0);
  assert.equal(fake.rules.length, 0);
});

test('worker restart restores persisted player ownership and rules; orphan wrappers are closed', async () => {
  const fake = fakeChrome(); const first = manager(fake); await first.players.ready();
  const { id } = await launch(fake, first.players);
  const second = manager(fake); await second.players.ready();
  assert.equal((await second.players.configure(fake.sender(id))).url, 'https://vsembed.su/embed/movie/123');
  assert.equal(hasCompletePlayerProtection(fake.rules, id), true);
  fake.tabs.set(999, { id: 999, url: fake.api.runtime.getURL('player.html') });
  const third = manager(fake); await third.players.ready();
  assert.equal(fake.tabs.has(999), false);
  await third.players.close(fake.sender());
});

test('launch timeout closes idle wrapper and cleans session/rules', async () => {
  const fake = fakeChrome(); const { players } = manager(fake, { launchTimeoutMs: 10 }); await players.ready();
  const opening = players.open(fake.sender(), selection);
  await assert.rejects(opening, /did not become ready/);
  assert.equal(fake.data[PLAYER_STORAGE_KEY].length, 0);
  assert.equal(fake.rules.length, 0);
});

test('popup closing is limited to managed players and handles noopener navigation targets', async () => {
  const fake = fakeChrome(); const { players } = installServiceWorker(fake.api); await players.ready();
  const { id } = await launch(fake, players);
  for (const popupId of [500, 501, 502]) fake.tabs.set(popupId, { id: popupId });
  fake.api.tabs.onCreated.emit({ id: 500, openerTabId: id });
  fake.api.webNavigation.onCreatedNavigationTarget.emit({ sourceTabId: id, tabId: 501 });
  fake.api.webNavigation.onCreatedNavigationTarget.emit({ sourceTabId: 43, tabId: 502 });
  await waitFor(() => !fake.tabs.has(500) && !fake.tabs.has(501));
  assert.equal(fake.tabs.has(502), true);
  assert.equal(fake.tabs.has(43), true);
  await players.close(fake.sender());
});

test('service worker rejects forged messages, and successful protection checks advertise player support', async () => {
  const fake = fakeChrome(); installServiceWorker(fake.api);
  const [listener] = fake.api.runtime.onMessage.listeners;
  assert.equal(listener({ type: 'OPEN_PLAYER', payload: selection }, { ...fake.sender(), frameId: 1 }, () => assert.fail()), false);
  assert.equal(listener({ type: 'PLAYER_READY' }, fake.sender(), () => assert.fail()), false);
  const result = await new Promise((resolve) => assert.equal(listener({ type: 'PROTECTION_CHECK' }, fake.sender(), resolve), true));
  assert.equal(result.active, true); assert.equal(result.playerSupported, true); assert.equal(result.version, '1.1.0');
});

test('isolated bridge forwards exact selections and correlates player action/nonce', async () => {
  const code = await fs.readFile(new URL('../extension/content-bridge.js', import.meta.url), 'utf8');
  let listener; const output = []; const sent = [];
  const page = { location: { origin: new URL(appUrl).origin }, addEventListener(type, fn) { listener = fn; }, postMessage(data, origin) { output.push({ data, origin }); } };
  vm.runInNewContext(code, { window: page, chrome: { runtime: { async sendMessage(value) { sent.push(value); return { ok: true }; } } } });
  const request = { channel: 'streambert-web', type: 'OPEN_PLAYER', nonce: 'request-123', payload: selection };
  await listener({ source: {}, origin: page.location.origin, data: request });
  assert.equal(sent.length, 0);
  await listener({ source: page, origin: page.location.origin, data: request });
  assert.equal(sent[0].type, 'OPEN_PLAYER'); assert.deepEqual(sent[0].payload, selection);
  assert.equal(output[0].data.type, 'PLAYER_RESULT'); assert.equal(output[0].data.action, 'OPEN_PLAYER');
  assert.equal(output[0].data.nonce, request.nonce); assert.equal(output[0].data.ok, true);
  assert.equal('url' in output[0].data, false);
});

test('wrapper never creates an iframe before verified configuration, rejects forged provider URL, and stops on failed checks', async () => {
  const code = await fs.readFile(new URL('../extension/player.js', import.meta.url), 'utf8');
  async function run(configuration) {
    let configure; let interval; let created = 0; let removed = 0;
    const replies = [];
    const elements = { '#player': { append() {} }, '#status': {}, '#protection-status': {}, '#title': {}, '#return-app': { addEventListener() {} } };
    const document = { querySelector(selector) { return elements[selector]; }, addEventListener() {}, createElement(type) { assert.equal(type, 'iframe'); created++; return { remove() { removed++; } }; } };
    const ready = new Promise((resolve) => { configure = resolve; });
    vm.runInNewContext(code, { document, URL, chrome: { runtime: { sendMessage({ type }) { if (type === 'PLAYER_READY') return ready; if (type === 'PLAYER_CHECK') return Promise.resolve({ ok: false }); replies.push(type); return Promise.resolve({ ok: true }); } } }, setInterval(fn) { interval = fn; } });
    assert.equal(created, 0, 'no iframe before rules/configuration response');
    configure(configuration);
    await new Promise((resolve) => setImmediate(resolve));
    return { get created() { return created; }, get removed() { return removed; }, interval, replies };
  }
  const invalid = await run({ ok: true, title: 'bad', url: 'https://evil.example/' });
  assert.equal(invalid.created, 0);
  const valid = await run({ ok: true, title: 'movie', url: 'https://vsembed.su/embed/movie/123' });
  assert.equal(valid.created, 1); assert.deepEqual(valid.replies, ['PLAYER_STARTED']);
  await valid.interval(); assert.equal(valid.removed, 1);
  assert.equal(code.includes("addEventListener('message'"), false, 'provider postMessage commands are not exposed');
  const manifest = JSON.parse(await fs.readFile(new URL('../extension/manifest.json', import.meta.url)));
  assert.equal(manifest.web_accessible_resources, undefined, 'provider cannot navigate to extension wrapper');
  assert.equal(manifest.permissions.includes('tabs'), false);
  assert.equal(manifest.host_permissions.some((host) => host.includes('<all_urls>')), false);
});
