import assert from 'node:assert/strict';
import test from 'node:test';
import { catalog } from '../src/catalog.js';
import { cleanMedia, escapeHtml, keyOf, mayEmbed, playerUrl, validateBackup } from '../src/core.js';

const movie = { id: 157336, type: 'movie', title: 'Interstellar', year: '2014', rating: '8.7', genres: ['Science Fiction'] };
const series = { id: 1396, type: 'tv', title: 'Breaking Bad', seasons: 5 };
const backup = (saved = [movie], history = []) => ({ format: 'streambert-web', version: 1, saved, history });

test('player routes retain upstream TMDB identifiers, selected season and selected episode', () => {
  const expected = {
    videasy: ['https://player.videasy.to/movie/157336', 'https://player.videasy.to/tv/1396/3/7'],
    vidsrc: ['https://vsembed.su/embed/movie/157336', 'https://vsembed.su/embed/tv/1396/3/7'],
    vidking: ['https://www.vidking.net/embed/movie/157336', 'https://www.vidking.net/embed/tv/1396/3/7'],
  };
  for (const [source, [movieUrl, tvUrl]] of Object.entries(expected)) {
    assert.equal(playerUrl(source, movie), movieUrl);
    assert.equal(playerUrl(source, series, 3, 7), tvUrl);
  }
});

test('player routes cannot become arbitrary URLs through malformed selections', () => {
  for (const media of [{ ...movie, id: 0 }, { ...movie, id: -1 }, { ...movie, id: '157336' }, { ...movie, id: Infinity }, { ...movie, id: Number.MAX_SAFE_INTEGER + 1 }, { ...movie, type: 'https://evil.test' }]) {
    assert.throws(() => playerUrl('videasy', media), String(media.id));
  }
  for (const source of ['https://evil.test', '__proto__', 'constructor', 'missing']) assert.throws(() => playerUrl(source, movie));
  for (const value of [0, -1, 1.5, '2', NaN, Infinity]) {
    assert.throws(() => playerUrl('vidsrc', series, value, 1));
    assert.throws(() => playerUrl('vidsrc', series, 1, value));
  }
});

test('embedded playback needs both affirmative blocking status and verified challenge', () => {
  assert.equal(mayEmbed({ active: true, nonceVerified: true }), true);
  for (const state of [{}, { active: true }, { nonceVerified: true }, { active: false, nonceVerified: true }, { active: true, nonceVerified: false }, { active: 'true', nonceVerified: true }, { active: true, nonceVerified: 1 }]) {
    assert.equal(mayEmbed(state), false, JSON.stringify(state));
  }
});

test('backup import keeps library data while excluding tokens and arbitrary image origins', () => {
  const imported = validateBackup({ ...backup([{ ...movie, poster: 'https://tracker.example/poster.jpg', backdrop: 'javascript:alert(1)', token: 'private', script: '<script>bad</script>' }]), token: 'secret' });
  assert.equal(imported.saved[0].title, movie.title);
  for (const key of ['poster', 'backdrop', 'token', 'script']) assert.equal(key in imported.saved[0], false, key);
  assert.equal('token' in imported, false);
  assert.equal(validateBackup(backup([{ ...movie, poster: '/posters/interstellar.jpg', backdrop: 'https://image.tmdb.org/t/p/w1280/test.jpg' }])).saved[0].poster, './posters/interstellar.jpg');
});

test('backup import rejects foreign formats, invalid titles and excessive collections', () => {
  for (const data of [null, {}, { ...backup(), format: 'streambert-desktop' }, { ...backup(), version: 2 }, { ...backup(), saved: {} }, backup([{ ...movie, id: '123' }]), backup([{ ...movie, id: 0 }]), backup([{ ...movie, type: 'person' }]), backup([{ ...movie, title: '<'.repeat(501) }]), backup(Array(2001).fill(movie)), backup([], Array(2001).fill(movie))]) {
    assert.throws(() => validateBackup(data));
  }
});

test('movie and series with the same numeric ID stay distinct while duplicate saved titles collapse', () => {
  const result = validateBackup(backup([movie, { ...movie, title: 'duplicate' }, { ...movie, type: 'tv' }]));
  assert.equal(result.saved.length, 2);
  assert.deepEqual(result.saved.map(keyOf), ['movie:157336', 'tv:157336']);
  const history = Array.from({ length: 105 }, (_, i) => ({ ...movie, id: i + 1, openedAt: i }));
  assert.equal(validateBackup(backup([], history)).history.length, 100);
});

test('TMDB list metadata supports the same visible filters as full detail metadata', () => {
  const list = cleanMedia({ id: 157336, title: 'Interstellar', media_type: 'movie', genre_ids: [878, 12, 18], release_date: '2014-11-05', vote_average: 8.4 }, 'movie');
  assert.equal(list.year, '2014');
  assert.ok(list.genres.includes('Science Fiction'));
  assert.ok(list.genres.includes('Adventure'));
  assert.ok(list.genres.includes('Drama'));
  const detail = cleanMedia({ id: 157336, title: 'Interstellar', genres: [{ id: 878, name: 'Science Fiction' }, { id: 12, name: 'Adventure' }] }, 'movie');
  assert.ok(detail.genres.includes('Science Fiction'));
  assert.ok(detail.genres.includes('Adventure'));
});

test('TV list and detail genres use consistent visible filter categories', () => {
  const list = cleanMedia({ id: 94605, name: 'Arcane', genre_ids: [16, 10759, 10765] }, 'tv');
  const detail = cleanMedia({ id: 94605, name: 'Arcane', genres: [{ id: 16, name: 'Animation' }, { id: 10759, name: 'Action & Adventure' }, { id: 10765, name: 'Sci-Fi & Fantasy' }] }, 'tv');
  assert.deepEqual(detail.genres, list.genres, 'opening full details must not remove a title from its genre filter');
  assert.ok(detail.genres.includes('Animation'));
  assert.ok(detail.genres.includes('Adventure'));
  assert.ok(detail.genres.includes('Science Fiction'));
});

test('starter collection has unique valid TMDB identities and local artwork', () => {
  const keys = catalog.map(keyOf);
  assert.equal(new Set(keys).size, catalog.length);
  for (const item of catalog) {
    assert.ok(Number.isSafeInteger(item.id) && item.id > 0);
    assert.ok(['movie', 'tv'].includes(item.type));
    assert.match(item.poster, /^\.\/posters\/[a-z0-9._-]+$/i);
    assert.ok(item.genres.length > 0);
  }
  assert.ok(catalog.some(item => item.type === 'movie'));
  assert.ok(catalog.some(item => item.type === 'tv'));
});

test('untrusted text is escaped for quoted attributes and HTML text', () => {
  assert.equal(escapeHtml('<img src=x onerror="alert(1)"> & \'quoted\''), '&lt;img src=x onerror=&quot;alert(1)&quot;&gt; &amp; &#39;quoted&#39;');
  assert.equal(escapeHtml(null), '');
});
