import assert from 'node:assert/strict';
import test from 'node:test';
import {readFile,access} from 'node:fs/promises';
import {catalog} from '../src/catalog.js';
import {validateBackup} from '../src/core.js';

const root=new URL('../',import.meta.url);
const appBases=['https://example.test/','https://saraaa2103.github.io/streambert/'];
const movie={id:157336,type:'movie',title:'Interstellar'};
const backup=poster=>({format:'streambert-web',version:1,saved:[{...movie,poster}],history:[]});

test('all entry-point assets and install manifest stay within the deployed app path',async()=>{
  const html=await readFile(new URL('index.html',root),'utf8');
  const assetPaths=[...html.matchAll(/(?:href|src)="([^"]+)"/g)].map(match=>match[1]);
  const manifest=JSON.parse(await readFile(new URL('public/manifest.webmanifest',root),'utf8'));
  assert.ok(assetPaths.length>=4);
  for(const base of appBases){
    for(const path of [...assetPaths,manifest.start_url,manifest.scope,...manifest.icons.map(icon=>icon.src)]){
      assert.ok(path.startsWith('./'),path);
      assert.ok(new URL(path,base).href.startsWith(base),path);
    }
    for(const path of assetPaths){
      const local=path.startsWith('./src/')||path==='./index.html'?path:'./public/'+path.slice(2);
      await access(new URL(local,root));
    }
  }
});

test('starter artwork, CSS fonts and app downloads work at the root and in a Pages subdirectory',async()=>{
  const css=await readFile(new URL('src/style.css',root),'utf8');
  const fonts=[...css.matchAll(/url\('([^']+\.woff2)'\)/g)].map(match=>match[1]);
  const app=await readFile(new URL('src/app.js',root),'utf8');
  const downloads=[...app.matchAll(/href="([^"]+)"(?: download| target="_blank">GPL)/g)].map(match=>match[1]);
  assert.equal(fonts.length,2);
  assert.ok(downloads.includes('./streambert-web-source.zip'));
  assert.ok(downloads.includes('./streambert-protection.zip'));
  assert.ok(downloads.includes('./LICENSE'));
  for(const base of appBases){
    for(const font of fonts){
      const url=new URL(font,new URL('src/style.css',base));
      assert.ok(url.href.startsWith(base+'fonts/'),url.href);
      await access(new URL('public/'+url.href.slice(base.length),root));
    }
    for(const artwork of catalog.flatMap(item=>[item.poster,item.backdrop]).filter(Boolean)){
      const url=new URL(artwork,base);
      assert.ok(url.href.startsWith(base+'posters/'),url.href);
      await access(new URL('public/'+url.href.slice(base.length),root));
    }
    for(const download of downloads)assert.ok(new URL(download,base).href.startsWith(base),download);
  }
});

test('backup artwork migrates known starter files to the current app base and retains TMDB artwork',()=>{
  for(const base of appBases){
    for(const poster of ['./posters/interstellar.jpg','posters/interstellar.jpg','/posters/interstellar.jpg',new URL('posters/interstellar.jpg',base).href,new URL('posters/interstellar.jpg',base).pathname]){
      const result=validateBackup(backup(poster),new URL(base));
      assert.equal(new URL(result.saved[0].poster,base).href,base+'posters/interstellar.jpg',poster);
    }
    const tmdb='https://image.tmdb.org/t/p/w342/sample_file.jpg';
    assert.equal(validateBackup(backup(tmdb),new URL(base)).saved[0].poster,tmdb);
  }
});

test('backup imports reject unrecognized local files, other apps and URL traversal',()=>{
  const base=new URL(appBases[1]);
  for(const poster of ['./posters/custom.jpg','/streambert/posters/custom.jpg','/other-app/posters/interstellar.jpg','https://saraaa2103.github.io/other-app/posters/interstellar.jpg','https://tracker.test/posters/interstellar.jpg','//tracker.test/posters/interstellar.jpg','./posters/../posters/interstellar.jpg','./posters/%2e%2e/posters/interstellar.jpg','./posters/interstellar.jpg?tracking=yes','./posters/interstellar.jpg#track','https://image.tmdb.org.evil.test/t/p/w342/sample.jpg','https://image.tmdb.org/t/p/w342/../../track.jpg']){
    assert.equal('poster' in validateBackup(backup(poster),base).saved[0],false,poster);
  }
});
