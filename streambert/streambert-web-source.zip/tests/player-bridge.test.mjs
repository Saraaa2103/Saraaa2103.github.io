import assert from 'node:assert/strict';
import test from 'node:test';
import {createPlayerBridge} from '../src/player-bridge.js';
import {mayLaunchPlayer} from '../src/core.js';

function fixture(){
 const listeners=new Set(),messages=[];
 const target={location:{origin:'https://app.example'},addEventListener(type,fn){listeners.add(fn);},removeEventListener(type,fn){listeners.delete(fn);},postMessage(data,origin){messages.push({data,origin});}};
 const dispatch=(message,overrides={})=>{for(const fn of listeners)fn({source:target,origin:target.location.origin,data:{channel:'streambert-protection',type:'PLAYER_RESULT',...message},...overrides});};
 let id=0;const bridge=createPlayerBridge(target,{timeoutMs:50,nonce:()=>`request-${++id}`});
 return {bridge,target,messages,dispatch};
}

test('old companions cannot accidentally launch an unprotected or incompatible player',()=>{
 assert.equal(mayLaunchPlayer({active:true,nonceVerified:true,playerSupported:true}),true);
 for(const value of [{active:true,nonceVerified:true},{active:false,nonceVerified:true,playerSupported:true},{active:true,nonceVerified:false,playerSupported:true},{active:true,nonceVerified:true,playerSupported:'true'}])assert.equal(mayLaunchPlayer(value),false);
});

test('only the matching action, origin, window and nonce can acknowledge player launch',async()=>{
 const f=fixture();let acknowledged=false;
 const request=f.bridge.request('OPEN_PLAYER',{source:'vidsrc',type:'movie',id:157336,season:1,episode:1,title:'Interstellar'}).then(()=>acknowledged=true);
 const message={nonce:'request-1',action:'OPEN_PLAYER',ok:true};
 f.dispatch(message,{source:{}});f.dispatch(message,{origin:'https://player.example'});f.dispatch({...message,nonce:'wrong'});f.dispatch({...message,action:'CLOSE_PLAYER'});
 await Promise.resolve();assert.equal(acknowledged,false);
 assert.deepEqual(f.messages[0],{origin:'https://app.example',data:{channel:'streambert-web',type:'OPEN_PLAYER',nonce:'request-1',payload:{source:'vidsrc',type:'movie',id:157336,season:1,episode:1,title:'Interstellar'}}});
 f.dispatch(message);await request;assert.equal(acknowledged,true);f.bridge.dispose();
});

test('concurrent focus and close acknowledgments cannot resolve each other',async()=>{
 const f=fixture();const focus=f.bridge.request('FOCUS_PLAYER');const close=f.bridge.request('CLOSE_PLAYER');
 f.dispatch({nonce:'request-2',action:'CLOSE_PLAYER',ok:true});await close;
 f.dispatch({nonce:'request-1',action:'FOCUS_PLAYER',ok:false,error:'Player was closed.'});await assert.rejects(focus,/Player was closed/);f.bridge.dispose();
});

test('a missing or unsupported companion times out with recovery guidance',async()=>{
 const f=fixture();await assert.rejects(f.bridge.request('OPEN_PLAYER'),/Update it to version 1\.1\.0/);await assert.rejects(f.bridge.request('UNTRUSTED_ACTION'),/Invalid player action/);f.bridge.dispose();
});
