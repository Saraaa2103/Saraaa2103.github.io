# Streambert Protection

This Manifest V3 companion applies the original Streambert ad/tracker list to the
Streambert web app's browser tab, including requests from embedded provider
frames. A website alone cannot intercept another origin's iframe requests. The
web app waits for this extension before loading a provider.

## Install in Chrome, Edge, Brave, or another desktop Chromium browser

1. Download and extract the protection ZIP, or use this `extension/` directory.
2. Open `chrome://extensions` (Edge: `edge://extensions`) and enable Developer mode.
3. Choose **Load unpacked** and select the extracted folder containing `manifest.json`.
4. Reload the Streambert app. Its protection status should become active.

The extension works on
`https://streambert-light-web.foggylyric32.chatgpt.site`,
`https://saraaa2103.github.io/streambert/`,
`http://localhost:5173`, and `http://127.0.0.1:5173`.
On GitHub Pages, only the `/streambert/` app directory is supported; other sites
on the same account do not activate protection. GitHub's `/streambert` redirect
is recognized by the policy, and the content bridge loads after the redirect.
Existing users should replace the package with version 1.0.1, choose **Reload**
on its extensions page, and reload the app. Changing the hosted URL requires
updating `APP_ORIGINS` and any path restrictions in `protection-policy.mjs` and
both URL lists in `manifest.json`, then reloading the extension. It is not
published in a browser extension store.
Mobile browsers and Safari/Firefox are not supported by this Chromium package.

## Permissions and scope

- `declarativeNetRequest` lets Chromium block requests before they leave the
  browser. Chrome may show a broad blocking permission warning. Only two session
  rules per protected Streambert tab are installed; other tabs are unaffected.
- Host permissions name the app origins above. Chromium ignores paths in host
  permissions, so the GitHub Pages content-script match and service-worker URL
  policy enforce `/streambert/*` before protection activates. See the
  [official match-pattern documentation](https://developer.chrome.com/docs/extensions/develop/concepts/match-patterns).
  Host access enables the isolated content bridge and reading the current app
  tab's URL. No `<all_urls>`, browsing
  history (`tabs`), cookies, webRequest, remote code, or analytics permissions are
  requested. With `declarativeNetRequest`, block rules do not require provider or
  tracker host permissions. See the [official DNR permission documentation](https://developer.chrome.com/docs/extensions/reference/api/declarativeNetRequest#permissions).
- Content scripts run only in the top frame on the app URLs. They do not read
  or inject code into streaming providers. No requests or playback data are sent
  to an extension server.

The 51 original patterns become 49 unique listed hostnames. Domain rules include
subdomains with proper hostname boundaries, and the upstream `yt3.ggpht.com/ytc/`
path restriction is retained. Top-level (`main_frame`) navigation is excluded.
The policy also covers websocket requests to the listed hosts. Inherited broad
hosts such as `googleapis.com` and `gstatic.com` can break provider resources;
the web app uses local fonts and does not silently disable protection.

## Bridge contract

The app sends a fresh random nonce for each check:

```js
window.postMessage({
  channel: 'streambert-web',
  type: 'PROTECTION_CHECK',
  nonce: crypto.randomUUID(),
}, window.location.origin);
```

After the service worker has installed **and read back** both per-tab rules, the
isolated content script responds:

```js
{
  channel: 'streambert-protection',
  type: 'PROTECTION_STATUS',
  nonce: 'the-request-nonce',
  active: true,
  version: '1.0.1',
  blockedDomains: 49
}
```

Failures return `active: false` plus a human-readable `reason`. The app must
check `event.source === window`, `event.origin === location.origin`, the channel,
type, and current nonce. The handshake is a local readiness signal, not
cryptographic attestation against compromised code already running in the app.
Cross-origin provider frames cannot send accepted bridge requests.

Session rule state lives in Chromium, so service worker suspension/restart does
not disable it or allocate duplicate rule IDs. Mutations are serialized. Rules
are removed when their tab closes or navigates away. Browser restarts and
extension updates clear session rules; the app must recheck before playback.
Recheck periodically during playback and stop the iframe when a check fails.
After manually disabling/reloading the extension, reload the app as well.

## Limits and verification

This preserves an upstream list, not a continuously updated universal blocker.
Ads or trackers on unlisted hosts, first-party/in-stream promotions, cached
provider service-worker content, and unknown tracking mechanisms may remain.
The active status reports rule readiness and list size, not an observed count of
blocked requests. A local app handshake cannot promise zero tracking.

Provider `X-Frame-Options`, CSP and browser security headers remain intact.
Providers that prohibit embedding can fail to play. The extension never strips
those headers, changes user agents, redirects requests, or bypasses access
controls. The app must sandbox provider frames without popup or top-navigation
permission because an iframe sandbox provides that separate protection.

Run the policy/lifecycle tests from the project root:

```sh
node --test tests/protection.test.mjs
```

For a manual browser check, load the extension, open the app, and inspect the
extension service worker at `chrome://extensions`. Evaluate
`await chrome.declarativeNetRequest.getSessionRules()`; every rule must include
only the app tab's ID. An ad-host request from that tab should fail with
`ERR_BLOCKED_BY_CLIENT`, while the same resource in an unrelated tab should not
be blocked by this extension. Close the app tab and confirm its rules disappear.
The automated tests simulate browser APIs; they do not replace this integration
check in your own browser.
