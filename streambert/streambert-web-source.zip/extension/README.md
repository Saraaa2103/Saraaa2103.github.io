# Streambert Protection 1.1.0

This Chromium companion applies Streambert’s original ad/tracker blocklist and
opens external playback in an extension-owned player tab. The web app waits for
the companion before it can open a provider. The separate tab fixes providers
that explicitly reject a sandboxed iframe: the provider remains cross-origin,
and cannot read Streambert’s app page or extension scripts.

## Install or update

1. Extract the latest protection ZIP, or use this `extension/` directory.
2. Open `chrome://extensions` (Edge: `edge://extensions`) and enable Developer mode.
3. Choose **Load unpacked** and select the folder containing `manifest.json`.
4. When updating an existing install, replace its extracted files and choose
   **Reload** on the extensions page. Confirm version **1.1.0**.
5. Reload Streambert, open a title, and choose **Play with protection**.

Supported app addresses:

- `https://streambert-light-web.foggylyric32.chatgpt.site`
- `https://saraaa2103.github.io/streambert/`
- `http://localhost:5173` and `http://127.0.0.1:5173`

Only the `/streambert/` directory on GitHub Pages activates protection. Other
projects on the account do not. Version 1.0.x cannot open the new player and must
be upgraded. Desktop Chromium browsers, including Chrome, Edge, and Brave, are
supported; Safari, Firefox, and mobile browsers are not supported by this package.
The extension is installed locally and is not published in an extension store.

## Protection and permissions

The original 51 patterns become 49 unique hostnames, with subdomain boundaries
and the upstream `yt3.ggpht.com/ytc/` restriction retained. Two verified session
rules cover the app tab and every nested provider frame’s resource requests. A
managed player has those same two rules plus a third rule blocking **all HTTP(S)
top-level navigations in that tab**, including redirects. Nested player/media
requests are allowed unless they match the blocklist.

The wrapper has no provider URL until the worker validates its owner, selection,
and sender and reads back all three installed rules. The website itself never
embeds a provider. The wrapper’s iframe has no sandbox because the providers
reject it. Browser cross-origin isolation, the extension page’s restrictive CSP,
and the tab’s navigation guard remain in effect. Provider `X-Frame-Options` and
CSP response headers are preserved. No response headers are stripped or relaxed.

New popup tabs from managed players are closed using `webNavigation` source-tab
information, including `noopener` popups, plus an opener-tab fallback. This is
**close after creation**: it cannot stop the popup’s initial request, or guarantee
that no transient popup appears. Other tabs’ popups are unaffected.

Permissions:

- `declarativeNetRequest` blocks matching requests before they leave the browser.
  Rule IDs and tab scopes are verified; app and player mutations share one queue.
- `storage` stores active owner/player associations in `chrome.storage.session`,
  so a suspended/restarted worker can resume cleanup and verification. It stores
  only tab IDs and the selected title/source, not a TMDB token or browsing log.
- `webNavigation` identifies popup source tabs. Chrome may present a browsing
  history permission warning for this API. The extension does not collect a
  browsing history and does not send data to a server.
- Host access is limited to the listed app addresses. Chromium ignores paths in
  host permissions, so the content-script match and worker policy additionally
  enforce the GitHub `/streambert/` directory. There is no `<all_urls>`, `tabs`,
  cookies, or `webRequest` permission and no provider content-script injection.

There is one player per app tab. A new selection replaces that tab’s previous
player. Closing the app or leaving a supported app address closes its player;
closing a player removes its rules. The extension closes the player **before**
removing its protection. If the close fails, rules/session remain. Session rules
survive worker suspension, and stored ownership is reconciled before responding
after restart. Browser restart/extension reload may clear session state; reload
the app and open a fresh player. The wrapper rechecks protection every 30 seconds
and on visibility changes and removes its iframe if the check fails.

This preserves a finite upstream list. Unlisted ads/trackers, first-party or
in-stream promotions, cached provider service-worker responses, and unknown
tracking mechanisms may remain. Listed broad domains such as `googleapis.com`
and `gstatic.com` can also break provider resources; protection is not silently
disabled. Provider availability and normal browser embedding restrictions still
apply. Active status reports rule readiness, not an observed blocked-request count.

## Bridge contract

From the app’s top frame and same origin, send a fresh nonce for each request:

```js
window.postMessage({
  channel: 'streambert-web',
  type: 'PROTECTION_CHECK',
  nonce: crypto.randomUUID(),
}, window.location.origin);
```

A successful response is:

```js
{
  channel: 'streambert-protection', type: 'PROTECTION_STATUS', nonce,
  active: true, playerSupported: true, version: '1.1.0', blockedDomains: 49
}
```

Failures return `active: false` with `reason`. Old versions may return active
without `playerSupported`; the app must require both, plus a verified nonce,
before offering playback. The content script verifies event source/origin;
the app must also check source, origin, channel, type, and its current nonce.
This is a local readiness handshake, not cryptographic attestation against
compromised code already running in the app.

To open a player:

```js
window.postMessage({
  channel: 'streambert-web', type: 'OPEN_PLAYER', nonce: crypto.randomUUID(),
  payload: { source: 'vidsrc', type: 'movie', id: 123, season: 1, episode: 1, title: 'Title' },
}, window.location.origin);
```

Known sources are `videasy`, `vidsrc`, and `vidking`; media types are `movie`
and `tv`. IDs must be positive safe integers, season is 1–1000, episode is
1–10000, and title is 1–240 characters without control characters. Unknown
fields and arbitrary URLs are rejected. The worker constructs the provider URL.
A wrapper receives configuration only when its runtime ID, exact extension page
URL, top frame, managed tab ID, current app owner, and rules are valid.

`FOCUS_PLAYER` and `CLOSE_PLAYER` use the same message shape without `payload`.
These actions affect only the requesting app tab’s player. Their response is:

```js
{ channel: 'streambert-protection', type: 'PLAYER_RESULT', nonce,
  action: 'OPEN_PLAYER', ok: true }
```

Failure responses include `ok: false` and `error`. `OPEN_PLAYER` succeeds only
after the wrapper receives configuration, starts its iframe, and acknowledges
startup with protection verified again. An incomplete launch times out and
closes after 15 seconds. No provider URL or internal session data is exposed
in app bridge results. Provider frames have no extension command/message bridge.

## Verification

```sh
node --test tests/protection.test.mjs tests/player-extension.test.mjs
```

Tests cover policy fidelity, exact sender/selection validation, rule readback,
concurrent allocation, launch acknowledgment and timeout, owner cleanup,
worker restart, scoped popups, and fail-closed wrapper behavior. They simulate
Chrome APIs. A real browser check should also confirm that playback works,
blocked resources fail with `ERR_BLOCKED_BY_CLIENT`, player top-level HTTP(S)
navigation is blocked, and unrelated tabs remain unaffected.
