(() => {
  const pending = new Set();
  const actions = new Set(['PROTECTION_CHECK', 'OPEN_PLAYER', 'FOCUS_PLAYER', 'CLOSE_PLAYER']);
  window.addEventListener('message', async (event) => {
    const message = event.data;
    if (event.source !== window || event.origin !== window.location.origin ||
        message?.channel !== 'streambert-web' || !actions.has(message.type) ||
        typeof message.nonce !== 'string' || !message.nonce || message.nonce.length > 200 ||
        pending.has(message.nonce) || pending.size >= 10) return;
    pending.add(message.nonce);
    let result;
    try {
      result = await chrome.runtime.sendMessage({ type: message.type,
        ...(message.type === 'OPEN_PLAYER' ? { payload: message.payload } : {}) });
    } catch {
      result = { active: false, ok: false, error: 'The protection extension needs to be reloaded.' };
    } finally {
      pending.delete(message.nonce);
    }
    if (message.type === 'PROTECTION_CHECK') {
      window.postMessage({
        channel: 'streambert-protection', type: 'PROTECTION_STATUS', nonce: message.nonce,
        active: result?.active === true,
        ...(result?.active === true
          ? { version: result.version, blockedDomains: result.blockedDomains, playerSupported: result.playerSupported === true }
          : { reason: result?.reason ?? 'Protection is unavailable.' }),
      }, window.location.origin);
    } else {
      window.postMessage({ channel: 'streambert-protection', type: 'PLAYER_RESULT', nonce: message.nonce,
        action: message.type, ok: result?.ok === true,
        ...(result?.ok === true ? {} : { error: result?.error ?? 'The protected player is unavailable.' }),
      }, window.location.origin);
    }
  });
})();
