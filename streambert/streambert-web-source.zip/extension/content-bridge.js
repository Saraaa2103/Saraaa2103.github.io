(() => {
  // Runs in the isolated extension world, in the app's top frame only.
  const pending = new Set();
  window.addEventListener('message', async (event) => {
    const message = event.data;
    if (event.source !== window || event.origin !== window.location.origin ||
        message?.channel !== 'streambert-web' || message.type !== 'PROTECTION_CHECK' ||
        typeof message.nonce !== 'string' || !message.nonce || message.nonce.length > 200 ||
        pending.has(message.nonce) || pending.size >= 10) return;
    pending.add(message.nonce);
    let result;
    try {
      result = await chrome.runtime.sendMessage({ type: 'PROTECTION_CHECK' });
    } catch {
      result = { active: false, reason: 'The protection extension needs to be reloaded.' };
    } finally {
      pending.delete(message.nonce);
    }
    window.postMessage({
      channel: 'streambert-protection', type: 'PROTECTION_STATUS', nonce: message.nonce,
      active: result?.active === true,
      ...(result?.active === true
        ? { version: result.version, blockedDomains: result.blockedDomains }
        : { reason: result?.reason ?? 'Protection is unavailable.' }),
    }, window.location.origin);
  });
})();
