import { BLOCKED_DOMAIN_COUNT, isAllowedAppUrl } from './protection-policy.mjs';
import { createSessionProtection } from './session-protection.mjs';

const protection = createSessionProtection(chrome);

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message?.type !== 'PROTECTION_CHECK' || sender.id !== chrome.runtime.id ||
      sender.frameId !== 0 || !Number.isInteger(sender.tab?.id) || !isAllowedAppUrl(sender.url)) {
    return false;
  }
  protection.ensure(sender.tab.id).then(() => {
    sendResponse({
      active: true,
      version: chrome.runtime.getManifest().version,
      blockedDomains: BLOCKED_DOMAIN_COUNT,
    });
  }).catch(() => sendResponse({ active: false, reason: 'Protection could not be installed. Reload the app and extension.' }));
  return true;
});

chrome.tabs.onRemoved.addListener((tabId) => { void protection.remove(tabId).catch(console.error); });
chrome.tabs.onUpdated.addListener((tabId, changes, tab) => {
  // URL is intentionally unavailable for unrelated pages without broad tabs access.
  // A missing URL is treated as outside the app and its rules are removed.
  if ((changes.url || changes.status === 'loading') && !isAllowedAppUrl(tab.url)) {
    void protection.remove(tabId).catch(console.error);
  }
});
chrome.runtime.onInstalled.addListener(() => { void protection.prune().catch(console.error); });
chrome.runtime.onStartup.addListener(() => { void protection.prune().catch(console.error); });
