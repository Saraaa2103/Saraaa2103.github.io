import { BLOCKED_DOMAIN_COUNT } from './protection-policy.mjs';
import { createDnrQueue, createSessionProtection } from './session-protection.mjs';
import { createPlayerManager } from './player-manager.mjs';
import { isAppSender, isPlayerSender } from './player-policy.mjs';

export function installServiceWorker(chromeApi) {
  const protection = createSessionProtection(chromeApi, createDnrQueue());
  const players = createPlayerManager(chromeApi, protection);
  const errorResult = () => ({ ok: false, error: 'The protected player is unavailable. Reload the app and extension, then try again.' });

  chromeApi.runtime.onMessage.addListener((message, sender, sendResponse) => {
    let operation;
    if (message?.type === 'PROTECTION_CHECK' && isAppSender(chromeApi, sender)) {
      operation = players.ready().then(() => protection.ensure(sender.tab.id)).then(() => ({
        active: true, playerSupported: true, version: chromeApi.runtime.getManifest().version,
        blockedDomains: BLOCKED_DOMAIN_COUNT,
      })).catch(() => ({ active: false, reason: 'Protection could not be installed. Reload the app and extension.' }));
    } else if (isAppSender(chromeApi, sender) && ['OPEN_PLAYER', 'FOCUS_PLAYER', 'CLOSE_PLAYER'].includes(message?.type)) {
      operation = players[({ OPEN_PLAYER: 'open', FOCUS_PLAYER: 'focus', CLOSE_PLAYER: 'close' })[message.type]](sender, message.payload).catch(errorResult);
    } else if (isPlayerSender(chromeApi, sender) && ['PLAYER_READY', 'PLAYER_CHECK', 'PLAYER_STARTED', 'PLAYER_RETURN'].includes(message?.type)) {
      operation = (message.type === 'PLAYER_RETURN' ? players.returnToOwner(sender) : message.type === 'PLAYER_STARTED' ? players.acknowledge(sender) : players.configure(sender)).catch(errorResult);
    } else {
      return false;
    }
    operation.then(sendResponse);
    return true;
  });

  chromeApi.tabs.onRemoved.addListener((tabId) => { void players.onRemoved(tabId).catch(console.error); });
  chromeApi.tabs.onUpdated.addListener((tabId, changes, tab) => { void players.onUpdated(tabId, changes, tab).catch(console.error); });
  chromeApi.tabs.onCreated.addListener((tab) => {
    if (Number.isInteger(tab.openerTabId)) void players.closePopup(tab.openerTabId, tab.id).catch(console.error);
  });
  chromeApi.webNavigation.onCreatedNavigationTarget.addListener(({ sourceTabId, tabId }) => {
    void players.closePopup(sourceTabId, tabId).catch(console.error);
  });
  // Session storage and DNR session rules survive worker suspension. A new
  // worker reconciles them before answering any bridge or player request.
  chromeApi.runtime.onInstalled.addListener(() => { void players.ready().catch(console.error); });
  chromeApi.runtime.onStartup.addListener(() => { void players.ready().catch(console.error); });
  return { players, protection };
}

if (typeof chrome !== 'undefined') installServiceWorker(chrome);
