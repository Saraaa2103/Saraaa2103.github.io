import {
  allocateRuleIds, createProtectionRules, createPlayerProtectionRules,
  hasCompleteProtection, hasCompletePlayerProtection, isAllowedAppUrl, ruleBelongsToTab,
} from './protection-policy.mjs';

/** One queue is shared by all app and player rule mutations. */
export function createDnrQueue() {
  let queue = Promise.resolve();
  return (operation) => {
    const next = queue.then(operation, operation);
    queue = next.catch(() => {});
    return next;
  };
}

export function createSessionProtection(chromeApi, enqueue = createDnrQueue()) {
  async function removeTabRules(tabId) {
    const rules = await chromeApi.declarativeNetRequest.getSessionRules();
    const removeRuleIds = rules.filter((rule) => ruleBelongsToTab(rule, tabId)).map((rule) => rule.id);
    if (removeRuleIds.length) await chromeApi.declarativeNetRequest.updateSessionRules({ removeRuleIds });
  }

  function ensure(tabId, player = false) {
    return enqueue(async () => {
      const allowed = (tab) => player
        ? tab.url === chromeApi.runtime.getURL('player.html')
        : isAllowedAppUrl(tab.url);
      const complete = player ? hasCompletePlayerProtection : hasCompleteProtection;
      const create = player ? createPlayerProtectionRules : createProtectionRules;
      const tab = await chromeApi.tabs.get(tabId);
      if (!allowed(tab)) {
        // Only app callers use this cleanup. A managed player must be closed
        // before its live iframe can lose its rules.
        if (!player) await removeTabRules(tabId);
        throw new Error('Protection is only available in a Streambert app tab or managed player.');
      }
      const rules = await chromeApi.declarativeNetRequest.getSessionRules();
      if (!complete(rules, tabId)) {
        const removeRuleIds = rules.filter((rule) => ruleBelongsToTab(rule, tabId)).map((rule) => rule.id);
        const remaining = rules.filter((rule) => !removeRuleIds.includes(rule.id));
        await chromeApi.declarativeNetRequest.updateSessionRules({
          removeRuleIds, addRules: create(tabId, allocateRuleIds(remaining, player ? 3 : 2)),
        });
      }
      const installed = await chromeApi.declarativeNetRequest.getSessionRules();
      if (!complete(installed, tabId)) throw new Error('Protection rule verification failed.');
      if (!allowed(await chromeApi.tabs.get(tabId))) {
        if (!player) await removeTabRules(tabId);
        throw new Error('The tab navigated away before protection was ready.');
      }
      return true;
    });
  }

  return {
    ensure: (tabId) => ensure(tabId),
    ensurePlayer: (tabId) => ensure(tabId, true),
    remove: (tabId) => enqueue(() => removeTabRules(tabId)),
    prune: (managedPlayerIds = []) => enqueue(async () => {
      const [rules, tabs] = await Promise.all([
        chromeApi.declarativeNetRequest.getSessionRules(), chromeApi.tabs.query({}),
      ]);
      const players = new Set(managedPlayerIds);
      const validTabs = new Set(tabs.filter((tab) => isAllowedAppUrl(tab.url) ||
        (players.has(tab.id) && tab.url === chromeApi.runtime.getURL('player.html'))).map((tab) => tab.id));
      const removeRuleIds = rules.filter((rule) => {
        const ids = rule.condition?.tabIds;
        return !ids || ids.length !== 1 || !validTabs.has(ids[0]);
      }).map((rule) => rule.id);
      if (removeRuleIds.length) await chromeApi.declarativeNetRequest.updateSessionRules({ removeRuleIds });
    }),
  };
}
