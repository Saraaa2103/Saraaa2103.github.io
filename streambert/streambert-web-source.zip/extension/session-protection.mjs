import {
  allocateRuleIds, createProtectionRules, hasCompleteProtection,
  isAllowedAppUrl, ruleBelongsToTab,
} from './protection-policy.mjs';

/**
 * Serialize DNR mutations so concurrent tabs cannot allocate the same rule IDs.
 * The browser's session rule store is the source of truth, so worker suspension
 * and restart neither lose protection nor require persisting an in-memory map.
 */
export function createSessionProtection(chromeApi) {
  let queue = Promise.resolve();
  const enqueue = (operation) => {
    const next = queue.then(operation, operation);
    queue = next.catch(() => {});
    return next;
  };

  async function removeTabRules(tabId) {
    const rules = await chromeApi.declarativeNetRequest.getSessionRules();
    const removeRuleIds = rules.filter((rule) => ruleBelongsToTab(rule, tabId)).map((rule) => rule.id);
    if (removeRuleIds.length) await chromeApi.declarativeNetRequest.updateSessionRules({ removeRuleIds });
  }

  return {
    ensure: (tabId) => enqueue(async () => {
      const tab = await chromeApi.tabs.get(tabId);
      if (!isAllowedAppUrl(tab.url)) {
        await removeTabRules(tabId);
        throw new Error('Protection is only available in a Streambert app tab.');
      }
      const rules = await chromeApi.declarativeNetRequest.getSessionRules();
      if (!hasCompleteProtection(rules, tabId)) {
        const removeRuleIds = rules.filter((rule) => ruleBelongsToTab(rule, tabId)).map((rule) => rule.id);
        const remaining = rules.filter((rule) => !removeRuleIds.includes(rule.id));
        await chromeApi.declarativeNetRequest.updateSessionRules({
          removeRuleIds,
          addRules: createProtectionRules(tabId, allocateRuleIds(remaining)),
        });
      }
      // Never acknowledge active based only on an attempted update.
      const installed = await chromeApi.declarativeNetRequest.getSessionRules();
      if (!hasCompleteProtection(installed, tabId)) throw new Error('Protection rule verification failed.');
      const currentTab = await chromeApi.tabs.get(tabId);
      if (!isAllowedAppUrl(currentTab.url)) {
        await removeTabRules(tabId);
        throw new Error('The tab navigated away before protection was ready.');
      }
      return true;
    }),
    remove: (tabId) => enqueue(() => removeTabRules(tabId)),
    prune: () => enqueue(async () => {
      const [rules, tabs] = await Promise.all([
        chromeApi.declarativeNetRequest.getSessionRules(), chromeApi.tabs.query({}),
      ]);
      const validTabs = new Set(tabs.filter((tab) => isAllowedAppUrl(tab.url)).map((tab) => tab.id));
      const removeRuleIds = rules.filter((rule) => {
        const ids = rule.condition?.tabIds;
        return !ids || ids.length !== 1 || !validTabs.has(ids[0]);
      }).map((rule) => rule.id);
      if (removeRuleIds.length) await chromeApi.declarativeNetRequest.updateSessionRules({ removeRuleIds });
    }),
  };
}
