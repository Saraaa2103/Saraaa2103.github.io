import { isAllowedAppUrl } from './protection-policy.mjs';
import { createDnrQueue } from './session-protection.mjs';
import { isAppSender, isPlayerSender, selectedProviderUrl, validatePlayerSelection } from './player-policy.mjs';

export const PLAYER_STORAGE_KEY = 'streambertPlayerSessions';
const LAUNCH_TIMEOUT_MS = 15000;

export function createPlayerManager(chromeApi, protection, { launchTimeoutMs = LAUNCH_TIMEOUT_MS } = {}) {
  const sessions = new Map();
  const launches = new Map();
  const enqueue = createDnrQueue();
  const wrapperUrl = chromeApi.runtime.getURL('player.html');
  const save = () => chromeApi.storage.session.set({ [PLAYER_STORAGE_KEY]: [...sessions.values()] });
  const findPlayer = (id) => [...sessions.values()].find((session) => session.playerTabId === id);

  async function getTab(id) {
    try { return await chromeApi.tabs.get(id); } catch { return undefined; }
  }

  async function assertOwner(ownerTabId, expectedUrl) {
    const owner = await getTab(ownerTabId);
    if (!owner || !isAllowedAppUrl(owner.url) || (expectedUrl && expectedUrl !== owner.url)) {
      throw new Error('The Streambert app tab is no longer available.');
    }
    return owner;
  }

  function settle(playerTabId, error) {
    const launch = launches.get(playerTabId);
    if (!launch) return;
    clearTimeout(launch.timer);
    launches.delete(playerTabId);
    if (error) launch.reject(error); else launch.resolve({ ok: true });
  }

  async function closeSession(session, reason = 'The player was closed before it was ready.') {
    // Keep rules and the persisted owner association until the live iframe has
    // gone. A failed close must never leave a running, unprotected player.
    if (await getTab(session.playerTabId)) {
      try { await chromeApi.tabs.remove(session.playerTabId); }
      catch (error) { if (await getTab(session.playerTabId)) throw error; }
    }
    await protection.remove(session.playerTabId);
    if (sessions.get(session.ownerTabId)?.playerTabId === session.playerTabId) sessions.delete(session.ownerTabId);
    settle(session.playerTabId, new Error(reason));
    await save();
  }

  const startup = (async () => {
    const saved = (await chromeApi.storage.session.get(PLAYER_STORAGE_KEY))[PLAYER_STORAGE_KEY];
    for (const value of Array.isArray(saved) ? saved : []) {
      if (!value || !Number.isInteger(value.ownerTabId) || value.ownerTabId < 0 ||
          !Number.isInteger(value.playerTabId) || value.playerTabId < 0 || value.ownerTabId === value.playerTabId) continue;
      let selection;
      try { selection = validatePlayerSelection(value.selection); } catch { continue; }
      const [owner, player] = await Promise.all([getTab(value.ownerTabId), getTab(value.playerTabId)]);
      if (owner && isAllowedAppUrl(owner.url) && player?.url === wrapperUrl && !sessions.has(value.ownerTabId)) {
        sessions.set(value.ownerTabId, { ownerTabId: value.ownerTabId, playerTabId: value.playerTabId, selection });
      }
    }
    // A wrapper surviving an interrupted launch without a valid owner/session
    // cannot resume. Close it before pruning its rules.
    for (const tab of await chromeApi.tabs.query({})) {
      if (tab.url === wrapperUrl && !findPlayer(tab.id)) {
        await chromeApi.tabs.remove(tab.id);
        await protection.remove(tab.id);
      }
    }
    for (const session of [...sessions.values()]) {
      try { await protection.ensurePlayer(session.playerTabId); }
      catch { await closeSession(session, 'Player protection could not be restored.'); }
    }
    await save();
    await protection.prune([...sessions.values()].map((session) => session.playerTabId));
  })();
  // Event handlers and operations below await startup; avoid an unhandled
  // rejection if initialization fails before the first request arrives.
  startup.catch(() => {});

  function run(operation) { return enqueue(async () => { await startup; return operation(); }); }

  async function verifyApp(sender) {
    if (!isAppSender(chromeApi, sender)) throw new Error('Invalid Streambert app sender.');
    return assertOwner(sender.tab.id, sender.url);
  }

  return {
    ready: () => startup,
    open(sender, payload) {
      let selection;
      try { selection = validatePlayerSelection(payload); }
      catch (error) { return Promise.reject(error); }
      return run(async () => {
        await verifyApp(sender);
        const previous = sessions.get(sender.tab.id);
        if (previous) await closeSession(previous);
        // Create only an extension-owned shell. No provider request can begin
        // until PLAYER_READY has verified both kinds of browser rules.
        const tab = await chromeApi.tabs.create({ url: wrapperUrl, active: true });
        if (!Number.isInteger(tab?.id)) throw new Error('The protected player tab could not be created.');
        const session = { ownerTabId: sender.tab.id, playerTabId: tab.id, selection };
        sessions.set(sender.tab.id, session);
        let resolve, reject;
        const promise = new Promise((yes, no) => { resolve = yes; reject = no; });
        promise.catch(() => {});
        const launch = { resolve, reject, promise };
        launches.set(tab.id, launch);
        try {
          await save();
          await protection.ensurePlayer(tab.id);
          await assertOwner(sender.tab.id, sender.url);
          launch.timer = setTimeout(() => {
            void run(() => sessions.get(session.ownerTabId)?.playerTabId === session.playerTabId
              ? closeSession(session, 'The protected player did not become ready.') : undefined).catch(() => {});
          }, launchTimeoutMs);
          launch.timer.unref?.();
        } catch (error) {
          await closeSession(session, 'Player protection could not be installed.');
          throw error;
        }
        return { promise };
      }).then(({ promise }) => promise);
    },
    focus(sender) {
      return run(async () => {
        await verifyApp(sender);
        const session = sessions.get(sender.tab.id);
        if (!session) throw new Error('No protected player is open.');
        if ((await getTab(session.playerTabId))?.url !== wrapperUrl) {
          await closeSession(session);
          throw new Error('The protected player is no longer available.');
        }
        try { await protection.ensurePlayer(session.playerTabId); }
        catch (error) { await closeSession(session, 'Player protection is unavailable.'); throw error; }
        await chromeApi.tabs.update(session.playerTabId, { active: true });
        return { ok: true };
      });
    },
    close(sender) {
      return run(async () => {
        await verifyApp(sender);
        const session = sessions.get(sender.tab.id);
        if (session) await closeSession(session);
        return { ok: true };
      });
    },
    configure(sender) {
      return run(async () => {
        if (!isPlayerSender(chromeApi, sender)) throw new Error('Invalid protected player sender.');
        const session = findPlayer(sender.tab.id);
        if (!session || (await getTab(session.playerTabId))?.url !== wrapperUrl) {
          throw new Error('This player has no active Streambert app session.');
        }
        try {
          await assertOwner(session.ownerTabId);
          await protection.ensurePlayer(session.playerTabId);
          await assertOwner(session.ownerTabId);
          return { ok: true, url: selectedProviderUrl(session.selection), title: session.selection.title };
        } catch (error) {
          await closeSession(session, 'Player protection is unavailable.');
          throw error;
        }
      });
    },
    acknowledge(sender) {
      return run(async () => {
        if (!isPlayerSender(chromeApi, sender)) throw new Error('Invalid protected player sender.');
        const session = findPlayer(sender.tab.id);
        if (!session || (await getTab(session.playerTabId))?.url !== wrapperUrl) {
          throw new Error('This player has no active Streambert app session.');
        }
        try {
          await assertOwner(session.ownerTabId);
          await protection.ensurePlayer(session.playerTabId);
          settle(session.playerTabId);
          return { ok: true };
        } catch (error) {
          await closeSession(session, 'Player protection is unavailable.');
          throw error;
        }
      });
    },
    returnToOwner(sender) {
      return run(async () => {
        if (!isPlayerSender(chromeApi, sender)) throw new Error('Invalid protected player sender.');
        const session = findPlayer(sender.tab.id);
        if (!session) throw new Error('This player has no active Streambert app session.');
        await assertOwner(session.ownerTabId);
        await chromeApi.tabs.update(session.ownerTabId, { active: true });
        return { ok: true };
      });
    },
    onRemoved(tabId) {
      return run(async () => {
        const session = sessions.get(tabId) || findPlayer(tabId);
        if (session) await closeSession(session);
        await protection.remove(tabId);
      });
    },
    onUpdated(tabId, changes, tab) {
      return run(async () => {
        if (!(changes.url || changes.status === 'loading')) return;
        const owned = sessions.get(tabId);
        if (owned && !isAllowedAppUrl(tab.url)) await closeSession(owned);
        const player = findPlayer(tabId);
        if (player && tab.url !== wrapperUrl) await closeSession(player);
        if (!player && !isAllowedAppUrl(tab.url)) await protection.remove(tabId);
      });
    },
    closePopup(sourceTabId, popupTabId) {
      const wasManaged = Boolean(findPlayer(sourceTabId));
      return run(async () => {
        if (!Number.isInteger(popupTabId) || (!wasManaged && !findPlayer(sourceTabId)) ||
            sessions.has(popupTabId) || findPlayer(popupTabId)) return;
        // onCreatedNavigationTarget also reports noopener windows. This closes
        // a new tab after creation; it cannot prevent its first request.
        try { await chromeApi.tabs.remove(popupTabId); } catch { /* already closed */ }
      });
    },
  };
}
