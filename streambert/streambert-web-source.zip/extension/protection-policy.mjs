/**
 * Canonical protection policy. Kept inside extension/ so Load unpacked needs no build.
 * The web app consumes the same exports through shared/protection-policy.mjs.
 * Source: truelockmc/streambert index.js BLOCKED_HOSTS, including its /ytc/ exception.
 */
const GITHUB_PAGES_ORIGIN = 'https://saraaa2103.github.io';
const GITHUB_PAGES_PATH = '/streambert';

export const APP_ORIGINS = Object.freeze([
  'https://streambert-light-web.foggylyric32.chatgpt.site',
  GITHUB_PAGES_ORIGIN,
  'http://localhost:5173',
  'http://127.0.0.1:5173',
]);

export const ORIGINAL_BLOCK_PATTERNS = Object.freeze([
  '*://www.google-analytics.com/*',
  '*://analytics.google.com/*',
  '*://googletagmanager.com/*',
  '*://www.googletagmanager.com/*',
  '*://googletagservices.com/*',
  '*://doubleclick.net/*',
  '*://*.doubleclick.net/*',
  '*://adservice.google.com/*',
  '*://adservice.google.de/*',
  '*://pagead2.googlesyndication.com/*',
  '*://stats.g.doubleclick.net/*',
  '*://yt3.ggpht.com/ytc/*',
  '*://fonts.googleapis.com/*',
  '*://fonts.gstatic.com/*',
  '*://googleapis.com/*',
  '*://gstatic.com/*',
  '*://cdn.adx1.com/*',
  '*://intelligenceadx.com/*',
  '*://adsco.re/*',
  '*://mc.yandex.com/*',
  '*://mc.yandex.ru/*',
  '*://bvtpk.com/*',
  '*://my.rtmark.net/*',
  '*://bvtpk.com/*',
  '*://b7510.com/*',
  '*://gt.unbrownunflat.com/*',
  '*://im.malocacomals.com/*',
  '*://users.videasy.net/*',
  '*://nf.sixmossin.com/*',
  '*://realizationnewestfangs.com/*',
  '*://acscdn.com/*',
  '*://lt.taloseempest.com/*',
  '*://pl26708123.profitableratecpm.com/*',
  '*://preferencenail.com/*',
  '*://protrafficinspector.com/*',
  '*://s10.histats.com/*',
  '*://weirdopt.com/*',
  '*://static.cloudflareinsights.com/*',
  '*://kettledroopingcontinuation.com/*',
  '*://wayfarerorthodox.com/*',
  '*://woxaglasuy.net/*',
  '*://adeptspiritual.com/*',
  '*://www.calculating-laugh.com/*',
  '*://amavhxdlofklxjg.xyz/*',
  '*://7jtjubf8p5kq7x3z2.u3qleufcm6vure326ktfpbj.cfd/*',
  '*://5mq.get64t9vqg8pnbex1y463o.rest/*',
  '*://usrpubtrk.com/*',
  '*://adexchangeclear.com/*',
  '*://rzjzjnavztycv.online/*',
  '*://tmstr4.cloudnestra.com/*',
  '*://tmstr4.neonhorizonworkshops.com/*',
]);

const uniqueDomains = [...new Set(ORIGINAL_BLOCK_PATTERNS.map((pattern) =>
  pattern.replace(/^\*:\/\//, '').split('/')[0].replace(/^\*\./, '')
))].sort();

export const BLOCKED_DOMAINS = Object.freeze(uniqueDomains);
export const BLOCKED_DOMAIN_COUNT = BLOCKED_DOMAINS.length;
export const PATH_BLOCKED_DOMAIN = 'yt3.ggpht.com';
export const FULLY_BLOCKED_DOMAINS = Object.freeze(
  BLOCKED_DOMAINS.filter((domain) => domain !== PATH_BLOCKED_DOMAIN),
);

// main_frame deliberately absent: rules cover app + provider resources only.
export const BLOCKED_RESOURCE_TYPES = Object.freeze([
  'sub_frame', 'stylesheet', 'script', 'image', 'font', 'object',
  'xmlhttprequest', 'ping', 'csp_report', 'media', 'websocket', 'other',
]);

export function isAllowedAppUrl(value) {
  try {
    const url = new URL(value);
    if (url.username || url.password || !APP_ORIGINS.includes(url.origin)) return false;
    if (url.origin !== GITHUB_PAGES_ORIGIN) return true;

    // This origin also hosts unrelated sites. Only the canonical app directory
    // (or GitHub Pages' slash-adding redirect) may activate per-tab protection.
    const rawPath = typeof value === 'string'
      ? value.match(/^[a-z][a-z\d+.-]*:\/\/[^/?#]*([^?#]*)/i)?.[1]
      : undefined;
    if (rawPath !== url.pathname || /%(?:2e|2f|5c)/i.test(rawPath)) return false;
    return url.pathname === GITHUB_PAGES_PATH || url.pathname.startsWith(`${GITHUB_PAGES_PATH}/`);
  } catch {
    return false;
  }
}

export function hostMatchesDomain(hostname, domain) {
  const host = hostname.toLowerCase().replace(/\.$/, '');
  const normalizedDomain = domain.toLowerCase().replace(/\.$/, '');
  return host === normalizedDomain || host.endsWith(`.${normalizedDomain}`);
}

/** Reference matcher for policy previews/tests; Chromium enforces the real DNR rules. */
export function shouldBlockRequest({ url, resourceType, tabId }, protectedTabId) {
  if (tabId !== protectedTabId || !BLOCKED_RESOURCE_TYPES.includes(resourceType)) return false;
  try {
    const parsed = new URL(url);
    if (!['http:', 'https:', 'ws:', 'wss:'].includes(parsed.protocol)) return false;
    if (FULLY_BLOCKED_DOMAINS.some((domain) => hostMatchesDomain(parsed.hostname, domain))) return true;
    return hostMatchesDomain(parsed.hostname, PATH_BLOCKED_DOMAIN) && parsed.pathname.startsWith('/ytc/');
  } catch {
    return false;
  }
}

export function createProtectionRules(tabId, ruleIds) {
  if (!Number.isInteger(tabId) || tabId < 0) throw new TypeError('A valid tab ID is required.');
  if (!Array.isArray(ruleIds) || ruleIds.length !== 2 || new Set(ruleIds).size !== 2 ||
      ruleIds.some((id) => !Number.isInteger(id) || id < 1 || id > 2147483647)) {
    throw new TypeError('Two distinct positive rule IDs are required.');
  }
  const commonCondition = {
    tabIds: [tabId],
    resourceTypes: [...BLOCKED_RESOURCE_TYPES],
  };
  return [
    {
      id: ruleIds[0], priority: 1, action: { type: 'block' },
      condition: { ...commonCondition, requestDomains: [...FULLY_BLOCKED_DOMAINS] },
    },
    {
      id: ruleIds[1], priority: 1, action: { type: 'block' },
      condition: {
        ...commonCondition,
        requestDomains: [PATH_BLOCKED_DOMAIN],
        // Domain filtering handles subdomains; regex keeps the upstream path scope.
        regexFilter: '^(https?|wss?)://[^/]+/ytc/',
        isUrlFilterCaseSensitive: true,
      },
    },
  ];
}

export function ruleBelongsToTab(rule, tabId) {
  return rule.condition?.tabIds?.length === 1 && rule.condition.tabIds[0] === tabId;
}

/** Stable signatures make validation independent of Chrome's object key ordering. */
export function ruleSignature(rule) {
  return JSON.stringify({
    priority: rule.priority ?? 1,
    action: rule.action,
    tabIds: rule.condition?.tabIds,
    resourceTypes: [...(rule.condition?.resourceTypes ?? [])].sort(),
    requestDomains: [...(rule.condition?.requestDomains ?? [])].sort(),
    regexFilter: rule.condition?.regexFilter,
    isUrlFilterCaseSensitive: rule.condition?.isUrlFilterCaseSensitive ?? false,
    // Unknown conditions must not accidentally pass verification as a complete policy.
    conditionKeys: Object.keys(rule.condition ?? {}).sort(),
  });
}

export function hasCompleteProtection(rules, tabId) {
  const actual = rules.filter((rule) => ruleBelongsToTab(rule, tabId));
  if (actual.length !== 2) return false;
  const expectedSignatures = createProtectionRules(tabId, [1, 2]).map(ruleSignature).sort();
  return JSON.stringify(actual.map(ruleSignature).sort()) === JSON.stringify(expectedSignatures);
}

export function allocateRuleIds(rules, count = 2) {
  const used = new Set(rules.map((rule) => rule.id));
  const result = [];
  for (let id = 1; result.length < count && id <= 2147483647; id += 1) {
    if (!used.has(id)) result.push(id);
  }
  if (result.length !== count) throw new Error('No available rule IDs.');
  return result;
}
