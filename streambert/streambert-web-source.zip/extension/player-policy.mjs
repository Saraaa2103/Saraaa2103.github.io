import { isAllowedAppUrl } from './protection-policy.mjs';

const SOURCES = Object.freeze({ videasy: 'https://player.videasy.to/', vidsrc: 'https://vsembed.su/embed/', vidking: 'https://www.vidking.net/embed/' });
const fields = ['source', 'type', 'id', 'season', 'episode', 'title'];

/** Accept a selection, never a caller-supplied provider URL. */
export function validatePlayerSelection(value) {
  if (!value || typeof value !== 'object' || Array.isArray(value) ||
      Object.keys(value).some((key) => !fields.includes(key)) ||
      !Object.hasOwn(SOURCES, value.source) || !['movie', 'tv'].includes(value.type) ||
      !Number.isSafeInteger(value.id) || value.id < 1 ||
      !Number.isInteger(value.season) || value.season < 1 || value.season > 1000 ||
      !Number.isInteger(value.episode) || value.episode < 1 || value.episode > 10000 ||
      typeof value.title !== 'string' || !value.title.trim() || value.title.length > 240 ||
      /[\u0000-\u001f\u007f]/.test(value.title)) {
    throw new Error('Invalid player selection.');
  }
  return Object.fromEntries(fields.map((key) => [key, key === 'title' ? value[key].trim() : value[key]]));
}

export function selectedProviderUrl(value) {
  const selection = validatePlayerSelection(value);
  return SOURCES[selection.source] + (selection.type === 'movie'
    ? `movie/${selection.id}` : `tv/${selection.id}/${selection.season}/${selection.episode}`);
}

export function isAppSender(chromeApi, sender) {
  return sender?.id === chromeApi.runtime.id && sender.frameId === 0 &&
    Number.isInteger(sender.tab?.id) && sender.tab.id >= 0 && isAllowedAppUrl(sender.url);
}

export function isPlayerSender(chromeApi, sender) {
  return sender?.id === chromeApi.runtime.id && sender.frameId === 0 &&
    Number.isInteger(sender.tab?.id) && sender.tab.id >= 0 &&
    sender.url === chromeApi.runtime.getURL('player.html');
}
