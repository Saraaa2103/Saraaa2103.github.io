const player = document.querySelector('#player');
const status = document.querySelector('#status');
const protectionStatus = document.querySelector('#protection-status');
let iframe;
let checking = false;
let stopped = false;

function stop(message) {
  stopped = true;
  iframe?.remove();
  iframe = undefined;
  status.hidden = false;
  status.textContent = message;
  protectionStatus.textContent = 'Playback stopped. Return to Streambert and open the player again.';
}

function validConfiguration(result) {
  if (result?.ok !== true || typeof result.title !== 'string' || result.title.length > 240) return false;
  try {
    const url = new URL(result.url);
    return !url.username && !url.password && !url.search && !url.hash &&
      ((url.origin === 'https://player.videasy.to' && /^\/(movie\/[1-9]\d*|tv\/[1-9]\d*\/[1-9]\d*\/[1-9]\d*)$/.test(url.pathname)) ||
       (['https://vsembed.su', 'https://www.vidking.net'].includes(url.origin) && /^\/embed\/(movie\/[1-9]\d*|tv\/[1-9]\d*\/[1-9]\d*\/[1-9]\d*)$/.test(url.pathname)));
  } catch { return false; }
}

async function start() {
  try {
    const result = await chrome.runtime.sendMessage({ type: 'PLAYER_READY' });
    if (!validConfiguration(result)) throw new Error('Protection is unavailable.');
    document.querySelector('#title').textContent = result.title;
    document.title = `${result.title} · Streambert`;
    // The provider rejects iframe sandboxing. It runs cross-origin in this
    // isolated extension page only after its tab's DNR rules were verified.
    // No page/provider postMessage handler or navigation bridge is exposed.
    iframe = document.createElement('iframe');
    iframe.title = `${result.title} player`;
    iframe.allow = 'autoplay; fullscreen; picture-in-picture; encrypted-media';
    iframe.allowFullscreen = true;
    iframe.referrerPolicy = 'no-referrer';
    iframe.src = result.url;
    player.append(iframe);
    status.hidden = true;
    const started = await chrome.runtime.sendMessage({ type: 'PLAYER_STARTED' });
    if (started?.ok !== true) throw new Error('Protection is unavailable.');
    protectionStatus.textContent = 'Known ad and tracker hosts blocked · Navigation guard active';
  } catch {
    stop('The protected player could not start. Reload the extension and Streambert, then try again.');
  }
}

async function checkProtection() {
  if (checking || stopped || !iframe) return;
  checking = true;
  try {
    const result = await chrome.runtime.sendMessage({ type: 'PLAYER_CHECK' });
    if (!validConfiguration(result) || result.url !== iframe.src) throw new Error('Protection is unavailable.');
  } catch {
    stop('Protection is no longer available. The player has been stopped.');
  } finally { checking = false; }
}

document.querySelector('#return-app').addEventListener('click', async () => {
  try {
    const result = await chrome.runtime.sendMessage({ type: 'PLAYER_RETURN' });
    if (result?.ok !== true) throw new Error('App unavailable.');
  } catch { stop('The Streambert app tab is no longer available. Open Streambert again to continue.'); }
});
document.addEventListener('visibilitychange', () => { if (!document.hidden) void checkProtection(); });
setInterval(checkProtection, 30000);
void start();
