// One canonical policy, located inside the self-contained unpacked extension.
export * from '../extension/protection-policy.mjs';
