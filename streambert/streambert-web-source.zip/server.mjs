import http from 'node:http';
import { readFile } from 'node:fs/promises';
import { resolve, extname, sep } from 'node:path';
const root = process.cwd();
const mime = {'.html':'text/html','.js':'text/javascript','.mjs':'text/javascript','.css':'text/css','.json':'application/json','.webmanifest':'application/manifest+json','.svg':'image/svg+xml','.jpg':'image/jpeg','.png':'image/png','.woff2':'font/woff2','.zip':'application/zip','.txt':'text/plain'};
const server = http.createServer(async (req,res) => {
  try {
    const path = resolve(root, '.' + decodeURIComponent(new URL(req.url,'http://localhost').pathname));
    if (path !== root && !path.startsWith(root+sep)) {res.writeHead(403).end();return;}
    if (path.includes('/.git/') || path.includes('/.openai/')) {res.writeHead(403).end();return;}
    const file = path === root ? resolve(root,'index.html') : path;
    let data;
    try {data=await readFile(file);}catch {
      try {data=await readFile(resolve(root,'public',file.slice(root.length+1)));}catch {
        if (!file.endsWith('.zip')) throw new Error('Not found');
        data=await readFile(resolve(root,'dist',file.slice(root.length+1)));
      }
    }
    res.writeHead(200, {'Content-Type':mime[extname(file)]||'application/octet-stream','X-Content-Type-Options':'nosniff','Referrer-Policy':'no-referrer','Cache-Control':'no-cache'}).end(data);
  } catch {res.writeHead(404).end('Not found');}
});
server.listen(5173,'127.0.0.1',() => console.log('Local: http://localhost:5173'));
